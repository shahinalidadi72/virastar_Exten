<?php
/**
 * Virastar Persian Text Engine
 *
 * Stand-alone rule engine that fixes common Persian typography problems
 * in HTML content: ZWNJ (نیم‌فاصله), Arabic characters, spacing,
 * punctuation, contextual Persian digits and ellipsis.
 *
 * The engine is WordPress-independent (pure PHP) so it can be unit-tested
 * anywhere. It never touches HTML tags, attributes, script/style/pre/code
 * blocks or [shortcode] bodies — only visible text nodes.
 *
 * @package virastar
 */

if ( ! defined( 'VIRASTAR_VERSION' ) && ! defined( 'VIRASTAR_TESTING' ) ) {
        exit;
}

final class Virastar_Engine {

        /* Persian letter classes (with presentation forms). */
        const PC  = '\x{0600}-\x{06FF}\x{FB50}-\x{FDFF}\x{FE70}-\x{FEFF}';      // letters
        const PZC = '\x{0600}-\x{06FF}\x{FB50}-\x{FDFF}\x{FE70}-\x{FEFF}\x{200C}'; // letters + ZWNJ

        /** Words after which the standalone "تر" means "wet", not a comparative suffix. */
        private static $ter_exceptions = array(
                'زمین', 'پارچه', 'مو', 'لباس', 'حوله', 'چمن', 'علف', 'هوا', 'تخته', 'خاک', 'چوب', 'سیمان', 'خیره', 'خشک', 'مرطوب',
        );

        /** Always-joined word pairs (space form => ZWNJ form). */
        private static $dict_join = array(
                'هیچ کس'    => 'هیچ‌کس',
                'هیچ کجا'   => 'هیچ‌جا',
                'هیچ گاه'   => 'هیچ‌گاه',
                'هیچ گز'    => 'هیچ‌گز',
                'هم اکنون'  => 'هم‌اکنون',
                'همان طور'  => 'همان‌طور',
                'همان گونه' => 'همان‌گونه',
                'این طور'   => 'این‌طور',
                'آن طور'    => 'آن‌طور',
                'این گونه'  => 'این‌گونه',
                'آن گونه'   => 'آن‌گونه',
                'چنان که'   => 'چنان‌که',
                'گر چه'     => 'گرچه',
                'هم چنین'   => 'همچنین',
                'هم چنان'   => 'همچنان',
                'بیش تر'    => 'بیشتر',
                'هر چند'    => 'هرچند',
                'هم چنان که' => 'همچنان‌که',
                'به طور'    => 'به‌طور',
                'به عنوان'  => 'به‌عنوان',
                'به ویژه'   => 'به‌ویژه',
                'به علاوه'  => 'به‌علاوه',
                'به عبارت'  => 'به‌عبارت',
                'خواسته های' => 'خواسته‌های', // covered by suffix rule too; kept for clarity.
        );

        /** Arabic → Persian character map. */
        private static $char_map = array(
                'ي' => 'ی', // Arabic Yeh -> Farsi Yeh
                'ك' => 'ک', // Arabic Kaf -> Keheh
                'ة' => 'ه', // Teh Marbuta -> Heh
                'أ' => 'ا',
                'إ' => 'ا',
                'ٱ' => 'ا',
                'ـ' => '',  // Tatweel (kashida) removed
                '٠' => '۰', '١' => '۱', '٢' => '۲', '٣' => '۳', '٤' => '۴',
                '٥' => '۵', '٦' => '۶', '٧' => '۷', '٨' => '۸', '٩' => '۹',
        );

        /** Default rule switches. */
        public static function defaults() {
                return array(
                        'arabic'         => 1, // حروف عربی -> فارسی
                        'spaces'         => 1, // فاصله‌های اضافی
                        'punct'          => 1, // فاصله‌گذاری نشانه‌ها
                        'zwnj'           => 1, // نیم‌فاصله (می/نمی، پسوند ها/تر/ترین...)
                        'yeh'            => 1, // کسره اضافه (خانه ی -> خانه‌ی)
                        'dict'           => 1, // واژه‌های همیشه‌چسبیده
                        'digits'         => 1, // اعداد لاتین در بستر فارسی
                        'ellipsis'       => 1, // نقطه‌چین
                        'style_fix'      => 0, // می‌باشد -> است (اصلاح خودکار)
                        'autoscan_report'=> 1, // گزارش هنگام ذخیره
                        'autofix_on_save'=> 0, // اصلاح خودکار هنگام ذخیره (پیش‌فرض خاموش)
                );
        }

        /** Rule group -> Persian label. */
        public static function rule_labels() {
                return array(
                        'arabic'   => 'حروف عربی',
                        'spaces'   => 'فاصله‌های اضافی',
                        'punct'    => 'نشانه‌گذاری',
                        'zwnj'     => 'نیم‌فاصله',
                        'yeh'      => 'کسره اضافه',
                        'dict'     => 'واژه‌های چسبیده',
                        'digits'   => 'اعداد فارسی',
                        'ellipsis' => 'نقطه‌چین',
                        'style_fix'=> 'سبک نگارش',
                );
        }

        /**
         * Fix Persian typography inside an HTML string.
         *
         * @param string $html   Raw content (may contain HTML/shortcodes).
         * @param array  $opts   Rule switches (see defaults()).
         * @return array { text:string, counts:array, suggestions:array, samples:array, changed:bool }
         */
        public static function fix( $html, $opts = array() ) {
                $opts = wp_parse_args_test( is_array( $opts ) ? $opts : array(), self::defaults() );

                $state = array(
                        'counts'       => array(),
                        'suggestions'  => array(),
                        'samples'      => array(),
                        'opts'         => $opts,
                );

                $out = self::walk_segments( (string) $html, $state );
                $out = preg_replace( "/\n{3,}/", "\n\n", $out );

                $changed = ( $out !== (string) $html );

                return array(
                        'text'        => $out,
                        'counts'      => $state['counts'],
                        'suggestions' => $state['suggestions'],
                        'samples'     => $state['samples'],
                        'changed'     => $changed,
                );
        }

        /* ------------------------------------------------------------------ *
         * Segment walker: protect tags, script/style/pre/code, shortcodes
         * ------------------------------------------------------------------ */
        private static function walk_segments( $html, &$state ) {
                $segments = preg_split( '/(<[^>]+>)/u', $html, -1, PREG_SPLIT_DELIM_CAPTURE );

                $skip_stack = 0;
                $out = '';

                foreach ( $segments as $seg ) {
                        if ( '' === $seg ) { continue; }

                        if ( '<' === $seg[0] ) {
                                $out .= $seg; // Tag or HTML comment: keep untouched.

                                if ( preg_match( '/^<\s*(script|style|pre|code)\b/i', $seg, $m ) && ! preg_match( '/\/\s*>\s*$/', $seg ) ) {
                                        $skip_stack++;
                                } elseif ( 1 === preg_match( '/^<\s*\/\s*(script|style|pre|code)\b/i', $seg, $m2 ) && $skip_stack > 0 ) {
                                        $skip_stack--;
                                }
                                continue;
                        }

                        if ( $skip_stack > 0 ) {
                                $out .= $seg; // Inside protected block.
                                continue;
                        }

                        // Protect [shortcodes] bodies (attributes may contain URLs).
                        $parts = preg_split( '/(\[[^\[\]]*\])/u', $seg, -1, PREG_SPLIT_DELIM_CAPTURE );
                        foreach ( $parts as $p ) {
                                if ( '' === $p ) { continue; }
                                if ( '[' === $p[0] ) { $out .= $p; continue; }
                                $out .= self::apply_rules( $p, $state );
                        }
                }

                return $out;
        }

        /* ------------------------------------------------------------------ *
         * Rule pipeline for one plain-text segment
         * ------------------------------------------------------------------ */
        private static function apply_rules( $text, &$state ) {
                if ( '' === trim( $text ) ) { return $text; }
                $o = $state['opts'];

                if ( $o['arabic'] )  { $text = self::r_arabic( $text, $state ); }
                if ( $o['spaces'] )  { $text = self::r_spaces( $text, $state ); }
                if ( $o['ellipsis'] ){ $text = self::r_ellipsis( $text, $state ); }
                if ( $o['punct'] )   { $text = self::r_punct( $text, $state ); }
                if ( $o['zwnj'] )    { $text = self::r_zwnj_suffix( $text, $state );
                                       $text = self::r_zwnj_prefix( $text, $state ); }
                if ( $o['yeh'] )     { $text = self::r_yeh( $text, $state ); }
                if ( $o['dict'] )    { $text = self::r_dict( $text, $state ); }
                if ( $o['digits'] )  { $text = self::r_digits( $text, $state ); }

                // Style suggestions (report-only unless style_fix is on).
                $text = self::r_style( $text, $state );

                return $text;
        }

        private static function bump( &$state, $rule, $before, $after ) {
                $state['counts'][ $rule ] = ( isset( $state['counts'][ $rule ] ) ? $state['counts'][ $rule ] : 0 ) + 1;
                if ( ! isset( $state['samples'][ $rule ] ) || count( $state['samples'][ $rule ] ) < 3 ) {
                        $state['samples'][ $rule ][] = array( 'before' => $before, 'after' => $after );
                }
        }

        /* ------------------------- Rule: Arabic chars ------------------------- */
        private static function r_arabic( $text, &$state ) {
                $hits = preg_match_all( '/[يكةأإٱـ٠-٩]/u', $text );
                if ( $hits ) {
                        $sample = mb_substr( $text, 0, 40 );
                        $fixed  = strtr( $text, self::$char_map );
                        self::bump( $state, 'arabic', $sample, mb_substr( $fixed, 0, 40 ) );
                        return $fixed;
                }
                return $text;
        }

        /* ------------------------- Rule: extra spaces ------------------------- */
        private static function r_spaces( $text, &$state ) {
                $before = $text;
                $text   = preg_replace( '/[ \t]{2,}/', ' ', $text );            // multiple spaces
                $text   = preg_replace( '/[ \t]+(\r?\n)/', '$1', $text );        // trailing before newline
                $text   = preg_replace( '/(\r?\n)[ \t]+/', '$1', $text );        // leading after newline
                if ( $text !== $before ) {
                        self::bump( $state, 'spaces', self::clip( $before ), self::clip( $text ) );
                }
                return $text;
        }

        /* ------------------------- Rule: ellipsis ------------------------- */
        private static function r_ellipsis( $text, &$state ) {
                $fixed = preg_replace( '/\.{4,}/u', '…', $text );
                $fixed = preg_replace( '/(\x{2026})\x{2026}+/u', '$1', $fixed );
                if ( $fixed !== $text ) {
                        self::bump( $state, 'ellipsis', self::clip( $text ), self::clip( $fixed ) );
                }
                return $fixed;
        }

        /* ------------------------- Rule: punctuation spacing ------------------------- */
        private static function r_punct( $text, &$state ) {
                $before = $text;

                // No space before ، ؛ ؟ ! . : … ) »
                $text = preg_replace( '/[ ]+([،؛؟!:.\)»”…])/u', '$1', $text );
                // No space after ( «
                $text = preg_replace( '/([\ («“])[ ]+/u', '$1', $text );
                // Space after ، ؛ ؟ ! when directly followed by a Persian letter.
                $text = preg_replace( '/([،؛؟!])(?=[' . self::PC . '])/u', '$1 ', $text );
                // ( متن ) -> (متن)  handled above; also handle fullwidth leftovers.
                $text = preg_replace( '/[ ]+\)/u', ')', $text );

                if ( $text !== $before ) {
                        self::bump( $state, 'punct', self::clip( $before ), self::clip( $text ) );
                }
                return $text;
        }

        /* ------------------------- Rule: ZWNJ suffixes ------------------------- */
        private static function r_zwnj_suffix( $text, &$state ) {
                // پسوندهای واژه‌ساز: مانند نسخهٔ تأییدشده، ادامهٔ حرف فارسی بعد از آن‌ها مجاز است.
                $word_suffixes = 'ها|هایی|های|هایم|هایت|هایش|هایمان|هایتان|هایشان|ترین|تر';

                $text = preg_replace_callback(
                        '/([' . self::PZC . ']{2,})[ ]+(' . $word_suffixes . ')(?=[' . self::PC . '\x{200C}]|[\s،؛؟!.\(\)«»"…:،-]|$)/u',
                        function ( $m ) use ( &$state ) {
                                $word = $m[1];
                                $sfx  = $m[2];
                                // "تر"/"ترین" as comparative suffix only; skip when previous word is
                                // in the "wet" exception list (زمین تر بود, لباس تر شد, ...).
                                if ( in_array( $sfx, array( 'تر', 'ترین' ), true ) && in_array( $word, self::$ter_exceptions, true ) ) {
                                        return $m[0];
                                }
                                self::bump( $state, 'zwnj', $word . ' ' . $sfx, $word . '‌' . $sfx );
                                return $word . "\u{200C}" . $sfx;
                        },
                        $text
                );

                // پسوندهای ملکی کوتاه فقط در «پایان واژه» چسبانده می‌شوند؛ وگرنه آغاز
                // واژهٔ بعدی (مثل «ام» در «خرید امتحان») اشتباهی می‌چسبید.
                $poss_suffixes = 'ام|ات|اش|مان|تان|شان';

                return preg_replace_callback(
                        '/([' . self::PZC . ']{2,})[ ]+(' . $poss_suffixes . ')(?=[\s،؛؟!.\(\)«»"…:،-]|$)/u',
                        function ( $m ) use ( &$state ) {
                                self::bump( $state, 'zwnj', $m[1] . ' ' . $m[2], $m[1] . '‌' . $m[2] );
                                return $m[1] . "\u{200C}" . $m[2];
                        },
                        $text
                );
        }

        /* ------------------------- Rule: ZWNJ prefixes (می/نمی) ------------------------- */
        private static function r_zwnj_prefix( $text, &$state ) {
                return preg_replace_callback(
                        '/(^|[\s«“"\(])(ن?می)[ ]+([' . self::PC . ']+)(?=[\s،؛؟!.«»"…:،\)]|$)/u',
                        function ( $m ) use ( &$state ) {
                                $word = $m[3];
                                // "می" as wine: skip را/مان/تان/شان/های followers and very short leftovers.
                                if ( preg_match( '/^(را|مان|تان|شان|های)/u', $word ) || mb_strlen( $word ) < 2 ) {
                                        return $m[0];
                                }
                                self::bump( $state, 'zwnj', $m[2] . ' ' . $word, $m[2] . '‌' . $word );
                                return $m[1] . $m[2] . "\u{200C}" . $word;
                        },
                        $text
                );
        }

        /* ------------------------- Rule: kasre-ye ezafe (خانه ی) ------------------------- */
        private static function r_yeh( $text, &$state ) {
                return preg_replace_callback(
                        '/(^|[\s«“"\(])([' . self::PC . ']{3,}ه)[ ]+ی(?=[\s،؛؟!.«»"…:،\)]|$)/u',
                        function ( $m ) use ( &$state ) {
                                self::bump( $state, 'yeh', $m[2] . ' ی', $m[2] . '‌ی' );
                                return $m[1] . $m[2] . "\u{200C}ی";
                        },
                        $text
                );
        }

        /* ------------------------- Rule: always-joined words ------------------------- */
        private static function r_dict( $text, &$state ) {
                foreach ( self::$dict_join as $from => $to ) {
                        $pattern = '/(^|[\s«“"\(])(' . preg_quote( $from, '/' ) . ')(?=[\s»”"\)\.\!؟،:…]|$)/u';
                        $text    = preg_replace_callback(
                                $pattern,
                                function ( $m ) use ( &$state, $from, $to ) {
                                        self::bump( $state, 'dict', $from, $to );
                                        return $m[1] . $to;
                                },
                                $text
                        );
                }
                return $text;
        }

        /* ------------------------- Rule: contextual Persian digits ------------------------- */
        private static function r_digits( $text, &$state ) {
                // Array form of strtr is multibyte-safe (two-string form is byte-based and
                // corrupts Persian digits!). Keys are single ASCII digits.
                $digit_map = array(
                        '0' => '۰', '1' => '۱', '2' => '۲', '3' => '۳', '4' => '۴',
                        '5' => '۵', '6' => '۶', '7' => '۷', '8' => '۸', '9' => '۹',
                );
                $conv = function ( $run ) use ( $digit_map ) {
                        return strtr( $run, $digit_map );
                };

                // Pass 1: token mixes Persian letters + Latin digits (no Latin letters/@/#).
                $text = preg_replace_callback( '/\S+/u', function ( $m ) use ( $conv, &$state ) {
                        $tok = $m[0];
                        if ( preg_match( '/[' . self::PC . ']/u', $tok )
                                && preg_match( '/[0-9]/', $tok )
                                && ! preg_match( '/[A-Za-z@#_\/]/', $tok ) ) {
                                $fixed = preg_replace_callback( '/[0-9]+/', function ( $d ) use ( $conv, &$state, $tok ) {
                                        self::bump( $state, 'digits', self::clip( $tok ), self::clip( str_replace( $d[0], $conv( $d[0] ), $tok ) ) );
                                        return $conv( $d[0] );
                                }, $tok );
                                return $fixed;
                        }
                        return $tok;
                }, $text );

                // Pass 2: standalone number between Persian words: "سایت 24 ساعته".
                $text = preg_replace_callback(
                        '/([' . self::PC . '])[ ]+([0-9]{1,4})(?=[ ]+[' . self::PC . '])/u',
                        function ( $m ) use ( $conv, &$state ) {
                                self::bump( $state, 'digits', $m[1] . ' ' . $m[2], $m[1] . ' ' . $conv( $m[2] ) );
                                return $m[1] . ' ' . $conv( $m[2] );
                        },
                        $text
                );

                return $text;
        }

        /* ------------------------- Rule: style (می‌باشد -> است) ------------------------- */
        private static function r_style( $text, &$state ) {
                return preg_replace_callback(
                        '/(ن?می[\s\x{200C}]?باش[دين])/u',
                        function ( $m ) use ( &$state, $text ) {
                                if ( ! in_array( 'می‌باشد → است', $state['suggestions'], true ) ) {
                                        $state['suggestions'][] = 'می‌باشد → است (بهتر است از «است» استفاده کنید)';
                                }
                                if ( ! empty( $state['opts']['style_fix'] ) ) {
                                        self::bump( $state, 'style_fix', $m[1], 'است' );
                                        return 'است';
                                }
                                return $m[0];
                        },
                        $text
                );
        }

        private static function clip( $s, $len = 48 ) {
                $s = trim( preg_replace( '/\s+/u', ' ', $s ) );
                return ( mb_strlen( $s ) > $len ) ? mb_substr( $s, 0, $len ) . '…' : $s;
        }
}

/**
 * Minimal args merge used so the engine stays WP-free.
 */
function wp_parse_args_test( $args, $defaults ) {
        return array_merge( $defaults, (array) $args );
}
