<?php
/**
 * Virastar Admin: menu, options, graphical UI, free editor scan and
 * save_post report. Pro features (bulk scan/fix, CSV, auto-fix) live in
 * virastar-pro.php and are gated by the RTL license.
 *
 * @package virastar
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

final class Virastar_Admin {

        const CAP          = 'manage_options';
        const MENU_SLUG    = 'virastar';
        const OPT_KEY      = 'virastar_options';
        const LOG_KEY      = 'virastar_log';
        const META_REPORT  = '_virastar_report';
        const LOG_MAX      = 300;
        const BULK_BATCH   = 20;

        public static function init() {
                add_action( 'admin_menu', array( __CLASS__, 'admin_menu' ) );
                add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
                add_action( 'admin_post_virastar_save_options', array( __CLASS__, 'save_options' ) );
                add_action( 'admin_post_virastar_clear_log', array( __CLASS__, 'clear_log' ) );

                // امکان رایگان: اسکن تکی متن در ادیتور.
                add_action( 'wp_ajax_virastar_scan_text', array( __CLASS__, 'ajax_scan_text' ) );

                // امکانات حرفه‌ای (bulk scan/fix و CSV) در Virastar_Pro ثبت می‌شوند.

                add_action( 'save_post', array( __CLASS__, 'on_save_post' ), 10, 2 );

                // Classic editor button.
                add_action( 'media_buttons_context', array( __CLASS__, 'classic_button' ) );
        }

        /** آیا نسخه حرفه‌ای (لایسنس RTL) روی این نصب فعال است؟ */
        public static function pro_active() {
                return class_exists( 'Virastar_Pro' ) && Virastar_Pro::is_active();
        }

        /* ------------------------------------------------------------------ *
         * Bootstrap
         * ------------------------------------------------------------------ */
        public static function boot() {
                self::init();
        }

        public static function activate() {
                if ( false === get_option( self::OPT_KEY, false ) ) {
                        update_option( self::OPT_KEY, Virastar_Engine::defaults() );
                }
                if ( false === get_option( self::LOG_KEY, false ) ) {
                        update_option( self::LOG_KEY, array(), false );
                }
        }

        public static function deactivate() {
                /* Keep options and reports on deactivation. */
        }

        /* ------------------------------------------------------------------ *
         * Options / log helpers
         * ------------------------------------------------------------------ */
        public static function get_options() {
                $opts = get_option( self::OPT_KEY, array() );
                if ( ! is_array( $opts ) ) { $opts = array(); }
                return array_merge( Virastar_Engine::defaults(), $opts );
        }

        public static function get_log() {
                $log = get_option( self::LOG_KEY, array() );
                return is_array( $log ) ? $log : array();
        }

        public static function log_add( $entry ) {
                $log   = self::get_log();
                array_unshift( $log, $entry );
                $log   = array_slice( $log, 0, self::LOG_MAX );
                update_option( self::LOG_KEY, $log, false );
        }

        public static function log_update( $post_id, $entry ) {
                $log = self::get_log();
                foreach ( $log as $i => $row ) {
                        if ( isset( $row['id'] ) && (int) $row['id'] === (int) $post_id ) {
                                $log[ $i ] = $entry;
                                update_option( self::LOG_KEY, $log, false );
                                return;
                        }
                }
                self::log_add( $entry );
        }

        public static function analyze( $content, $opts = null ) {
                if ( null === $opts ) { $opts = self::get_options(); }
                return Virastar_Engine::fix( (string) $content, $opts );
        }

        public static function total_issues( $counts ) {
                $sum = 0;
                if ( is_array( $counts ) ) { $sum = array_sum( array_map( 'intval', $counts ) ); }
                return $sum;
        }

        /* ------------------------------------------------------------------ *
         * Menu + assets
         * ------------------------------------------------------------------ */
        public static function admin_menu() {
                add_menu_page( 'ویراستار', 'ویراستار', self::CAP, self::MENU_SLUG, array( __CLASS__, 'render_page' ), 'dashicons-editor-spellcheck', 59 );
        }

        public static function enqueue( $hook ) {
                $is_page   = ( 'toplevel_page_' . self::MENU_SLUG === $hook );
                $is_editor = in_array( $hook, array( 'post.php', 'post-new.php' ), true );

                if ( ! $is_page && ! $is_editor ) { return; }

                // Graphical admin stylesheet (fonts bundled locally).
                wp_enqueue_style( 'virastar-admin', VIRASTAR_URL . 'assets/admin.css', array(), VIRASTAR_VERSION );

                wp_enqueue_script( 'virastar-editor', VIRASTAR_URL . 'assets/editor.js', array( 'jquery' ), VIRASTAR_VERSION, true );
                wp_localize_script( 'virastar-editor', 'VirastarData', array(
                        'ajax'     => admin_url( 'admin-ajax.php' ),
                        'nonce'    => wp_create_nonce( 'virastar_ajax' ),
                        'scanBtn'  => 'ویراستاری متن',
                        'labels'   => Virastar_Engine::rule_labels(),
                        'isGutenberg' => ( function_exists( 'use_block_editor_for_post_type' ) && get_current_screen() && use_block_editor_for_post_type( get_current_screen()->post_type ) ) ? 1 : 0,
                ) );

                // امتیاز کیفیت محتوا و سئو (متاباکس ویرایشگر) — نسخه ۱.۳.
                wp_enqueue_script( 'virastar-score', VIRASTAR_URL . 'assets/score.js', array( 'jquery' ), VIRASTAR_VERSION, true );

                // اسکریپت اسکن/اصلاح انبوه فقط در نسخه حرفه‌ای بارگذاری می‌شود.
                if ( $is_page && self::pro_active() ) {
                        wp_enqueue_script( 'virastar-bulk', VIRASTAR_URL . 'assets/bulk.js', array( 'jquery' ), VIRASTAR_VERSION, true );
                        wp_localize_script( 'virastar-bulk', 'VirastarBulk', array(
                                'ids' => self::all_scannable_ids(),
                        ) );
                }
        }

        /** All post+page IDs (publish & draft) for bulk operations. */
        private static function all_scannable_ids() {
                $ids = get_posts( array(
                        'post_type'        => array( 'post', 'page' ),
                        'post_status'      => array( 'publish', 'draft' ),
                        'numberposts'      => 1000,
                        'orderby'          => 'ID',
                        'order'            => 'DESC',
                        'fields'           => 'ids',
                        'suppress_filters' => false,
                ) );
                return array_map( 'absint', (array) $ids );
        }

        /* ------------------------------------------------------------------ *
         * Main report page
         * ------------------------------------------------------------------ */
        /** Persian description for each rule (shown on toggle cards). */
        public static function rule_descriptions() {
                return array(
                        'arabic'    => 'يك و ك عربی به ی و ک فارسی تبدیل می‌شوند',
                        'spaces'    => 'فاصله‌های دوبل و فاصله ابتدا/انتهای متن حذف می‌شود',
                        'punct'     => 'فاصله‌گذاری درست دور ویرگول، نقطه و پرانتزها',
                        'zwnj'      => 'چسباندن می‌، نمی‌، ‌ها، ‌تر، ‌ترین، ‌ام با نیم‌فاصله',
                        'yeh'       => '«خانه ی» به «خانه‌ی» تبدیل می‌شود',
                        'dict'      => 'واژه‌نامه داخلی واژه‌های همیشه‌چسبیده (مثل گفت‌وگو)',
                        'digits'    => 'اعداد لاتین متن فارسی به ۰۱۲۳۴۵۶۷۸۹ تبدیل می‌شوند',
                        'ellipsis'  => 'نقطه‌نقطه‌های نامرتب به «…» استاندارد تبدیل می‌شود',
                        'style_fix' => '«می‌باشد» به «است» تبدیل می‌شود (متن رسمی‌تر)',
                );
        }

        public static function render_page() {
                if ( ! current_user_can( self::CAP ) ) { return; }
                $opts = self::get_options();
                $log  = self::get_log();
                $pro  = self::pro_active();

                $scanned = count( $log );
                $issues_rows = 0; $fixed_rows = 0; $pending_rows = 0; $pending_total = 0;
                foreach ( $log as $row ) {
                        $t = self::total_issues( $row['counts'] ?? array() );
                        if ( ! empty( $row['fixed'] ) ) { $fixed_rows++; }
                        elseif ( $t > 0 ) { $pending_rows++; $pending_total += $t; }
                        else { $issues_rows++; }
                }

                $active_rules = 0;
                foreach ( array_keys( Virastar_Engine::rule_labels() ) as $rk ) {
                        if ( ! empty( $opts[ $rk ] ) ) { $active_rules++; }
                }

                $labels = Virastar_Engine::rule_labels();
                $descs  = self::rule_descriptions();
                ?>
                <div class="wrap virastar-wrap" dir="rtl">

                        <?php if ( isset( $_GET['virastar_notice'] ) ) : ?>
                                <div class="vx-notice">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                                        <span><?php echo esc_html( sanitize_text_field( wp_unslash( $_GET['virastar_notice'] ) ) ); ?></span>
                                </div>
                        <?php endif; ?>

                        <!-- HERO -->
                        <section class="vx-hero">
                                <span class="vx-hero-badge">v<?php echo esc_html( VIRASTAR_VERSION ); ?></span>
                                <div class="vx-hero-main">
                                        <div class="vx-logo">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
                                        </div>
                                        <div>
                                                <h1>ویراستار</h1>
                                                <p>دستیار نگارش فارسی وردپرس؛ نیم‌فاصله، حروف عربی، فاصله‌گذاری، نشانه‌ها و اعداد را در همه نوشته‌ها خودکار درست می‌کند.</p>
                                        </div>
                                </div>
                                <div class="vx-hero-chips">
                                        <span class="vx-license-chip<?php echo $pro ? ' is-pro' : ' is-free'; ?>"><?php
                                                if ( defined( 'VIRASTAR_OPEN_MODE' ) && VIRASTAR_OPEN_MODE ) {
                                                        echo '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 17l2-9 4.5 4L12 5l2.5 7L19 8l2 9z"/><path d="M5 21h14"/></svg> نسخه باز — همه امکانات فعال';
                                                } elseif ( $pro ) {
                                                        echo '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 17l2-9 4.5 4L12 5l2.5 7L19 8l2 9z"/><path d="M5 21h14"/></svg> نسخه حرفه‌ای فعال';
                                                } else {
                                                        echo '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg> نسخه رایگان';
                                                }
                                        ?></span>
                                        <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M20 6 9 17l-5-5"/></svg> <?php echo esc_html( number_format_i18n( $active_rules ) ); ?> قاعده فعال</span>
                                        <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22a10 10 0 1 1 10-10"/><path d="M12 6v6l4 2"/></svg> پردازش کاملاً آفلاین</span>
                                        <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg> متن شما به بیرون ارسال نمی‌شود</span>
                                </div>
                        </section>

                        <!-- STATS -->
                        <div class="vx-stats">
                                <div class="vx-stat t-teal">
                                        <div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6"/><line x1="9" y1="13" x2="15" y2="13"/><line x1="9" y1="17" x2="13" y2="17"/></svg></div>
                                        <div><div class="num"><?php echo esc_html( number_format_i18n( $scanned ) ); ?></div><div class="lbl">مطالب بررسی‌شده</div></div>
                                </div>
                                <div class="vx-stat t-green">
                                        <div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg></div>
                                        <div><div class="num"><?php echo esc_html( number_format_i18n( $issues_rows ) ); ?></div><div class="lbl">بدون مشکل</div></div>
                                </div>
                                <div class="vx-stat t-amber">
                                        <div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></div>
                                        <div><div class="num"><?php echo esc_html( number_format_i18n( $pending_rows ) ); ?></div><div class="lbl">نیازمند اصلاح</div></div>
                                </div>
                                <div class="vx-stat t-violet">
                                        <div class="ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 21 9-9"/><path d="M15 4V2"/><path d="M15 16v-2"/><path d="M8 9h2"/><path d="M20 9h2"/><path d="M17.8 11.8 19 13"/><path d="M15 9h0"/><path d="M17.8 6.2 19 5"/><path d="m12.2 6.2-1.4-1.4"/><path d="M20 9a4 4 0 0 0-4-4"/></svg></div>
                                        <div><div class="num"><?php echo esc_html( number_format_i18n( $fixed_rows ) ); ?></div><div class="lbl">اصلاح‌شده</div></div>
                                </div>
                        </div>

                        <!-- CONTENT HEALTH (v1.3) -->
                        <?php if ( class_exists( 'Virastar_Score' ) && ( $health = Virastar_Score::health_snapshot() ) ) :
                                list( $health_key ) = Virastar_Score::grade_of( $health['avg'] );
                                $dist_labels = array( 'great' => 'عالی', 'good' => 'خوب', 'fair' => 'نیازمند بهبود', 'poor' => 'ضعیف' );
                                $dist_cls    = array( 'great' => 't-green', 'good' => 't-teal', 'fair' => 't-amber', 'poor' => 't-rose' );
                        ?>
                        <h2 class="vx-section-title">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                                سلامت محتوای سایت
                                <span class="hint">میانگین امتیاز کیفیت <?php echo esc_html( number_format_i18n( $health['count'] ) ); ?> نوشتهٔ بررسی‌شده</span>
                        </h2>
                        <div class="vx-health">
                                <div class="vx-health-dial is-<?php echo esc_attr( $health_key ); ?>" style="--p:<?php echo (int) $health['avg']; ?>">
                                        <b><?php echo esc_html( number_format_i18n( $health['avg'] ) ); ?></b>
                                        <span>میانگین از ۱۰۰</span>
                                </div>
                                <div class="vx-health-bars">
                                        <?php foreach ( $dist_labels as $dk => $dl ) :
                                                $cnt = (int) $health['dist'][ $dk ];
                                                $pct = $health['count'] ? round( $cnt / $health['count'] * 100 ) : 0; ?>
                                        <div class="vx-health-bar">
                                                <div class="lbl"><?php echo esc_html( $dl ); ?> <b><?php echo esc_html( number_format_i18n( $cnt ) ); ?></b></div>
                                                <div class="track"><i class="<?php echo esc_attr( $dist_cls[ $dk ] ); ?>" style="width:<?php echo (int) $pct; ?>%"></i></div>
                                        </div>
                                        <?php endforeach; ?>
                                </div>
                                <div class="vx-health-worst">
                                        <div class="t">ضعیف‌ترین نوشته‌ها</div>
                                        <ul>
                                        <?php foreach ( $health['worst'] as $wid => $wscore ) : ?>
                                                <li><a href="<?php echo esc_url( get_edit_post_link( $wid ) ); ?>"><?php echo esc_html( get_the_title( $wid ) ?: '(بدون عنوان)' ); ?></a><span class="pill"><?php echo esc_html( number_format_i18n( (int) $wscore ) ); ?></span></li>
                                        <?php endforeach; ?>
                                        </ul>
                                </div>
                        </div>
                        <?php endif; ?>

<!-- TOOLBAR -->
                        <div class="vx-toolbar">
                                <?php if ( $pro ) : ?>
                                <button type="button" class="vx-btn vx-btn-primary" id="virastar-bulk-scan">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                                        شروع اسکن انبوه
                                </button>
                                <button type="button" class="vx-btn vx-btn-soft" id="virastar-bulk-fix">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 21 9-9"/><path d="M15 4V2"/><path d="M15 16v-2"/><path d="M8 9h2"/><path d="M20 9h2"/><path d="M17.8 11.8 19 13"/><path d="M15 9h0"/><path d="M17.8 6.2 19 5"/><path d="m12.2 6.2-1.4-1.4"/><path d="M20 9a4 4 0 0 0-4-4"/></svg>
                                        اصلاح انبوه همه موارد
                                </button>
                                <span class="vx-spacer"></span>
                                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-flex">
                                        <input type="hidden" name="action" value="virastar_export_csv"><?php wp_nonce_field( 'virastar_export_csv' ); ?>
                                        <button type="submit" class="vx-btn vx-btn-ghost">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                                                خروجی CSV
                                        </button>
                                </form>
                                <?php else : ?>
                                <button type="button" class="vx-btn vx-btn-primary" onclick="var b=document.getElementById('vx-pro-banner');if(b){b.scrollIntoView({behavior:'smooth'});}">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                                        فعال‌سازی امکانات حرفه‌ای
                                </button>
                                <span class="vx-toolbar-note">اسکن و اصلاح انبوه و خروجی CSV در نسخه حرفه‌ای فعال می‌شود.</span>
                                <?php endif; ?>
                                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-flex"
                                        onsubmit="return confirm('همه گزارش‌های اسکن پاک شوند؟ محتوای مطالب تغییر نمی‌کند.');">
                                        <input type="hidden" name="action" value="virastar_clear_log"><?php wp_nonce_field( 'virastar_clear_log' ); ?>
                                        <button type="submit" class="vx-btn vx-btn-danger">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                                                پاک کردن گزارش‌ها
                                        </button>
                                </form>
                        </div>

                        <?php if ( ! $pro ) : ?>
                        <!-- PRO UPGRADE BANNER (free mode) -->
                        <div class="vx-pro-banner" id="vx-pro-banner">
                                <div class="vx-pro-ico">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 17l2-9 4.5 4L12 5l2.5 7L19 8l2 9z"/><path d="M5 21h14"/></svg>
                                </div>
                                <div class="vx-pro-body">
                                        <h3>امکانات حرفه‌ای ویراستار روی این نصب غیرفعال است</h3>
                                        <ul>
                                                <li>اسکن و اصلاح انبوه همه نوشته‌ها و برگه‌ها با نوار پیشرفت گرافیکی</li>
                                                <li>خروجی CSV از گزارش‌های اسکن (سازگار با اکسل)</li>
                                                <li>اصلاح خودکار متن دقیقاً هنگام ذخیره نوشته</li>
                                        </ul>
                                        <p>فعال‌سازی: در این نسخه همهٔ امکانات حرفه‌ای بدون نیاز به لایسنس فعال است؛ اگر این بنر را می‌بینید، افزونه را یک‌بار غیرفعال و دوباره فعال کنید.</p>
                                </div>
                        </div>
                        <?php endif; ?>

                                                <!-- PROGRESS -->
                        <?php if ( $pro ) : ?>
                        <div class="vx-progressbox" id="virastar-progressbox">
                                <div class="vx-progress-head">
                                        <span class="t">در حال پردازش انبوه…</span>
                                        <span class="pct" id="virastar-pct">۰٪</span>
                                </div>
                                <div id="virastar-progress"><div class="bar"></div></div>
                                <p id="virastar-status"></p>
                        </div>
                        <?php endif; ?>

                        <!-- RULES -->
                        <h2 class="vx-section-title">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>
                                تنظیمات قواعد
                                <span class="hint">روی هر کارت بزنید تا قاعده روشن/خاموش شود</span>
                        </h2>
                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                                <input type="hidden" name="action" value="virastar_save_options">
                                <?php wp_nonce_field( 'virastar_save_options' ); ?>

                                <div class="vx-rules-grid">
                                        <?php foreach ( $labels as $key => $label ) : $on = ! empty( $opts[ $key ] ); ?>
                                                <label class="vx-rule<?php echo $on ? ' is-on' : ''; ?><?php echo 'style_fix' === $key ? ' is-danger' : ''; ?>">
                                                        <span class="vx-rule-txt">
                                                                <strong><?php echo esc_html( $label ); ?> <span class="vx-state-tag"><?php echo $on ? 'روشن' : 'خاموش'; ?></span></strong>
                                                                <span><?php echo esc_html( $descs[ $key ] ?? '' ); ?></span>
                                                        </span>
                                                        <span class="vx-switch"><input type="checkbox" name="opts[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( $on ); ?>><i></i></span>
                                                </label>
                                        <?php endforeach; ?>

                                        <?php
                                        $on_report = ! empty( $opts['autoscan_report'] );
                                        $on_fix    = ! empty( $opts['autofix_on_save'] );
                                        ?>
                                        <label class="vx-rule<?php echo $on_report ? ' is-on' : ''; ?>">
                                                <span class="vx-rule-txt">
                                                        <strong>گزارش هنگام ذخیره نوشته <span class="vx-state-tag"><?php echo $on_report ? 'روشن' : 'خاموش'; ?></span></strong>
                                                        <span>موقع ذخیره هر نوشته، خطاها شمرده و در گزارش ثبت می‌شود؛ متن تغییر نمی‌کند.</span>
                                                </span>
                                                <span class="vx-switch"><input type="checkbox" name="opts[autoscan_report]" value="1" <?php checked( $on_report ); ?>><i></i></span>
                                        </label>
                                        <label class="vx-rule is-danger<?php echo $on_fix ? ' is-on' : ''; ?><?php echo $pro ? '' : ' is-locked'; ?>">
                                                <span class="vx-rule-txt">
                                                        <strong>اصلاح خودکار هنگام ذخیره <?php
                                                                if ( $pro ) {
                                                                        echo '<span class="vx-state-tag">' . ( $on_fix ? 'روشن' : 'خاموش' ) . '</span>';
                                                                } else {
                                                                        echo '<span class="vx-lock-tag">حرفه‌ای</span>';
                                                                }
                                                        ?></strong>
                                                        <span><?php echo $pro ? 'موقع ذخیره، متن خودکار اصلاح می‌شود. با احتیاط فعال کنید و اول بکاپ بگیرید!' : 'این امکان جزو نسخه حرفه‌ای است و با فعال‌شدن لایسنس در دسترس قرار می‌گیرد.'; ?></span>
                                                </span>
                                                <span class="vx-switch"><input type="checkbox" name="opts[autofix_on_save]" value="1" <?php checked( $on_fix ); ?><?php echo $pro ? '' : ' disabled'; ?>><i></i></span>
                                        </label>
                                </div>

                                <div class="vx-rules-save">
                                        <button type="submit" class="vx-btn vx-btn-primary">
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
                                                ذخیره تنظیمات
                                        </button>
                                        <span class="saved-note">تنظیمات روی اسکن‌ها و اصلاح‌های بعدی اعمال می‌شود.</span>
                                </div>
                        </form>

                        <!-- RESULTS TABLE -->
                        <h2 class="vx-section-title">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M3 15h18"/><path d="M9 3v18"/></svg>
                                آخرین نتایج اسکن
                                <?php if ( $pending_total > 0 ) : ?><span class="hint"><?php echo esc_html( number_format_i18n( $pending_total ) ); ?> مورد در انتظار اصلاح</span><?php endif; ?>
                        </h2>
                        <div class="vx-card">
                                <table class="widefat striped" id="virastar-table"><thead><tr>
                                        <th>مطلب</th><th>نوع</th><th>موارد</th><th>جزئیات</th><th>وضعیت</th><th>عملیات</th>
                                </tr></thead><tbody>
                                <?php if ( empty( $log ) ) : ?>
                                        <tr><td colspan="6" style="padding:0">
                                                <div class="vx-empty">
                                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="8" y1="11" x2="14" y2="11"/></svg>
                                                        <h3>هنوز اسکنی انجام نشده است</h3>
                                                        <?php if ( $pro ) : ?>
                                                        <p>با دکمه «شروع اسکن انبوه» همه نوشته‌ها را یک‌جا بررسی کنید، یا متنی را در ادیتور با دکمه «ویراستاری متن» امتحان کنید.</p>
                                                        <button type="button" class="vx-btn vx-btn-primary" onclick="document.getElementById('virastar-bulk-scan').click()">شروع کنید</button>
                                                        <?php else : ?>
                                                        <p>متنی را در ادیتور نوشته‌ها باز کنید و با دکمه «ویراستاری متن» آن را بررسی و اصلاح کنید. برای اسکن و اصلاح یک‌جای همه نوشته‌ها، نسخه حرفه‌ای را فعال کنید.</p>
                                                        <button type="button" class="vx-btn vx-btn-primary" onclick="var b=document.getElementById('vx-pro-banner');if(b){b.scrollIntoView({behavior:'smooth'});}">امکانات حرفه‌ای</button>
                                                        <?php endif; ?>
                                                </div>
                                        </td></tr>
                                <?php else : foreach ( $log as $row ) :
                                        $total = self::total_issues( $row['counts'] ?? array() );
                                        $detail = array();
                                        foreach ( ( $row['counts'] ?? array() ) as $k => $v ) {
                                                $detail[] = ( $labels[ $k ] ?? $k ) . ': ' . number_format_i18n( $v );
                                        }
                                        $is_fixed = ! empty( $row['fixed'] );
                                        ?>
                                        <tr data-id="<?php echo esc_attr( $row['id'] ); ?>">
                                                <td class="virastar-title"><a href="<?php echo esc_url( get_edit_post_link( $row['id'] ) ); ?>"><?php echo esc_html( get_the_title( $row['id'] ) ?: '(بدون عنوان)' ); ?></a></td>
                                                <td><?php echo 'page' === ( $row['type'] ?? 'post' ) ? 'برگه' : 'نوشته'; ?></td>
                                                <td><span class="virastar-pill <?php echo 0 === $total ? 'ok' : 'broken'; ?>"><?php echo esc_html( number_format_i18n( $total ) ); ?></span></td>
                                                <td class="virastar-detail"><?php echo esc_html( implode( '، ', $detail ) ?: '—' ); ?></td>
                                                <td><?php
                                                        if ( $is_fixed ) {
                                                                echo '<span class="vx-fixed-tag"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>اصلاح شد</span>';
                                                        } elseif ( 0 === $total ) {
                                                                echo '<span class="virastar-pill ok">سالم</span>';
                                                        } else {
                                                                echo '<span class="virastar-pill review">در انتظار</span>';
                                                        }
                                                ?></td>
                                                <td><?php if ( $pro && $total > 0 && ! $is_fixed ) : ?><button type="button" class="vx-btn vx-btn-soft virastar-fix-one" style="padding:4px 14px;font-size:12.5px">اصلاح</button><?php endif; ?></td>
                                        </tr>
                                <?php endforeach; endif; ?>
                                </tbody></table>
                        </div>

                        <div id="virastar-toasts"></div>
                </div>
                <?php
        }

        /* ------------------------------------------------------------------ *
         * Options / CSV / Clear handlers
         * ------------------------------------------------------------------ */
        public static function save_options() {
                if ( ! current_user_can( self::CAP ) ) { wp_die( 'دسترسی غیرمجاز است.', 403 ); }
                check_admin_referer( 'virastar_save_options' );

                $incoming = isset( $_POST['opts'] ) && is_array( $_POST['opts'] ) ? wp_unslash( $_POST['opts'] ) : array();
                $clean    = array();
                foreach ( array_keys( Virastar_Engine::defaults() ) as $key ) {
                        $clean[ $key ] = empty( $incoming[ $key ] ) ? 0 : 1;
                }
                update_option( self::OPT_KEY, $clean );

                wp_safe_redirect( add_query_arg( array( 'page' => self::MENU_SLUG, 'virastar_notice' => 'تنظیمات ذخیره شد.' ), admin_url( 'admin.php' ) ) );
                exit;
        }

        public static function clear_log() {
                if ( ! current_user_can( self::CAP ) ) { wp_die( 'دسترسی غیرمجاز است.', 403 ); }
                check_admin_referer( 'virastar_clear_log' );
                update_option( self::LOG_KEY, array(), false );
                wp_safe_redirect( add_query_arg( array( 'page' => self::MENU_SLUG, 'virastar_notice' => 'همه گزارش‌ها پاک شدند.' ), admin_url( 'admin.php' ) ) );
                exit;
        }

        /* ------------------------------------------------------------------ *
         * AJAX handlers
         * ------------------------------------------------------------------ */
        private static function ajax_guard( $capability = 'edit_posts' ) {
                if ( ! check_ajax_referer( 'virastar_ajax', 'nonce', false ) ) {
                        wp_send_json_error( array( 'message' => 'نشست منقضی شده؛ صفحه را تازه‌سازی کنید.' ), 403 );
                }
                if ( ! current_user_can( $capability ) ) {
                        wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز است.' ), 403 );
                }
        }

        /** Editor scan: receives raw content, returns fixed text + report. */
        public static function ajax_scan_text() {
                self::ajax_guard( 'edit_posts' );

                $content = isset( $_POST['content'] ) ? (string) wp_unslash( $_POST['content'] ) : '';
                $res     = self::analyze( $content );

                wp_send_json_success( array(
                        'fixed'       => $res['text'],
                        'counts'      => $res['counts'],
                        'suggestions' => $res['suggestions'],
                        'samples'     => $res['samples'],
                        'changed'     => $res['changed'],
                        'total'       => self::total_issues( $res['counts'] ),
                ) );
        }

        /* ------------------------------------------------------------------ *
         * save_post: auto report (and optional auto-fix)
         * ------------------------------------------------------------------ */
        public static function on_save_post( $post_id, $post ) {
                if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) { return; }
                if ( ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) { return; }
                if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }

                $opts = self::get_options();

                /* «اصلاح خودکار هنگام ذخیره» امکان حرفه‌ای است و در Virastar_Pro با
                 * اولویت ۲۰ اجرا می‌شود؛ اینجا در حالت حرفه‌ای فقط گزارش ثبت نمی‌شود
                 * تا شمارش روی متنِ اصلاح‌شده انجام گیرد. */
                if ( self::pro_active() && ! empty( $opts['autofix_on_save'] ) ) { return; }

                if ( empty( $opts['autoscan_report'] ) ) { return; }

                $res   = self::analyze( $post->post_content );
                $total = self::total_issues( $res['counts'] );
                update_post_meta( $post_id, self::META_REPORT, array(
                        'counts' => $res['counts'], 'suggestions' => $res['suggestions'], 'total' => $total, 'checked_at' => current_time( 'mysql' ),
                ) );
                self::log_update( $post_id, array(
                        'id' => $post_id, 'type' => $post->post_type, 'counts' => $res['counts'], 'fixed' => 0, 'checked_at' => current_time( 'mysql' ),
                ) );
                if ( class_exists( 'Virastar_Score' ) ) { Virastar_Score::store( $post_id ); }
        }

        /* ------------------------------------------------------------------ *
         * Classic editor button
         * ------------------------------------------------------------------ */
        public static function classic_button() {
                echo '<button type="button" id="virastar-btn" class="button" style="padding-left:8px">'
                        . '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>'
                        . ' ویراستاری متن</button>';
        }
}
