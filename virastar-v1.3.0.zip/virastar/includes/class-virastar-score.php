<?php
/**
 * Virastar Score — موتور امتیاز کیفیت محتوا و سئوی فارسی (نسخه ۱.۳).
 *
 * تحلیل کاملاً آفلاین و بدون ارسال داده: نگارش فارسی (با همان موتور ۹
 * قاعده‌ای)، خوانایی، پاراگراف‌بندی، ساختار عنوان‌ها و سئوی کلمه کلیدی
 * (عنوان، پاراگراف نخست، عنوان‌های داخلی و تراکم) را به یک امتیاز ۰ تا ۱۰۰
 * تبدیل می‌کند.
 *
 * متد analyze() عمداً بدون هیچ فراخوانی وردپرس نوشته شده تا خارج از
 * وردپرس هم قابل تست باشد؛ هوک‌های مدیریت (ستون فهرست نوشته‌ها، متاباکس،
 * AJAX) در boot() ثبت می‌شوند.
 *
 * @package virastar
 */

if ( ! defined( 'ABSPATH' ) && ! defined( 'VIRASTAR_TESTING' ) ) {
        exit;
}

final class Virastar_Score {

        const META_SCORE = '_virastar_score';
        const META_KW    = '_virastar_focus_kw';

        /* وزن بخش‌های امتیاز (جمع = ۱۰۰) */
        const W_ORTHO  = 40; // نگارش فارسی
        const W_READ   = 30; // خوانایی
        const W_STRUCT = 15; // پاراگراف‌بندی و ساختار
        const W_SEO    = 15; // سئوی کلمه کلیدی

        public static function boot() {
                add_action( 'wp_ajax_virastar_score', array( __CLASS__, 'ajax_score' ) );
                add_action( 'add_meta_boxes', array( __CLASS__, 'register_metabox' ) );

                add_filter( 'manage_post_posts_columns', array( __CLASS__, 'columns_head' ) );
                add_filter( 'manage_page_posts_columns', array( __CLASS__, 'columns_head' ) );
                add_action( 'manage_post_posts_custom_column', array( __CLASS__, 'columns_cell' ), 10, 2 );
                add_action( 'manage_page_posts_custom_column', array( __CLASS__, 'columns_cell' ), 10, 2 );

                add_action( 'admin_print_styles-edit.php', array( __CLASS__, 'list_styles' ) );
        }

        /* ================================================================== *
         * تحلیل (خالص؛ بدون فراخوانی وردپرس)
         * ================================================================== */

        /**
         * تحلیل کامل یک محتوای HTML.
         *
         * @param string     $html     محتوای خام (می‌تواند HTML باشد).
         * @param array|null $opts     سوئیچ قواعد موتور (null = پیش‌فرض سایت).
         * @param string     $title    عنوان نوشته.
         * @param string     $focus_kw کلمه کلیدی سئو (خالی = بدون تحلیل سئو).
         * @return array { score, grade, grade_key, stats, parts, checks, tips, issues, too_short }
         */
        public static function analyze( $html, $opts = null, $title = '', $focus_kw = '' ) {
                $html  = (string) $html;
                $plain = self::to_plain( $html );
                $stats = self::text_stats( $plain );

                $res = array(
                        'stats'     => $stats,
                        'parts'     => array(),
                        'checks'    => array(),
                        'tips'      => array(),
                        'issues'    => 0,
                        'score'     => null,
                        'grade'     => '',
                        'grade_key' => '',
                        'too_short' => true,
                );

                if ( $stats['words'] < 15 ) {
                        return $res;
                }
                $res['too_short'] = false;

                /* ---------------- ۱) نگارش فارسی (۴۰ امتیاز) ---------------- */
                if ( null === $opts ) {
                        $opts = class_exists( 'Virastar_Admin' ) ? Virastar_Admin::get_options() : Virastar_Engine::defaults();
                }
                $fix    = Virastar_Engine::fix( $html, is_array( $opts ) ? $opts : array() );
                $issues = 0;
                if ( isset( $fix['counts'] ) && is_array( $fix['counts'] ) ) {
                        $issues = (int) array_sum( array_map( 'intval', $fix['counts'] ) );
                }
                $sug      = ( isset( $fix['suggestions'] ) && is_array( $fix['suggestions'] ) ) ? count( $fix['suggestions'] ) : 0;
                $per100   = $issues * 100 / max( 1, $stats['words'] );
                $p_ortho  = min( self::W_ORTHO, $per100 * 8 + min( 6, $sug * 2 ) );
                $ortho    = max( 0, self::W_ORTHO - $p_ortho );

                $res['issues'] = $issues;
                $res['parts']['ortho'] = array(
                        'earned' => (int) round( $ortho ),
                        'max'    => self::W_ORTHO,
                        'issues' => $issues,
                        'per100' => round( $per100, 1 ),
                );

                $ortho_ok = ( $ortho >= self::W_ORTHO - 10 );
                $res['checks'][] = array(
                        'key'    => 'ortho',
                        'label'  => 'نگارش فارسی (نیم‌فاصله، حروف، نشانه‌ها)',
                        'state'  => $ortho_ok ? 'ok' : ( $ortho >= self::W_ORTHO - 20 ? 'warn' : 'bad' ),
                        'detail' => $issues
                                ? number_test( $issues ) . ' مورد قابل اصلاح (حدود ' . number_test( round( $per100 ) ) . ' مورد در هر ۱۰۰ واژه)'
                                : 'هیچ مورد نگارشی پیدا نشد',
                );
                if ( ! $ortho_ok ) {
                        $res['tips'][] = number_test( $issues ) . ' مورد نگارشی پیدا شد؛ با دکمهٔ «ویراستاری متن» آن‌ها را یک‌جا اصلاح کنید.';
                }

                /* ---------------- ۲) خوانایی (۳۰ امتیاز) ---------------- */
                $asl = $stats['sentences'] > 0 ? $stats['words'] / $stats['sentences'] : $stats['words'];
                $p1  = ( $asl <= 14 ) ? 0 : ( ( $asl <= 18 ) ? 3 : ( ( $asl <= 22 ) ? 7 : ( ( $asl <= 26 ) ? 12 : 15 ) ) );
                $lsr = $stats['sentences'] > 0 ? $stats['long_sentences'] / $stats['sentences'] : 0;
                $p2  = (int) min( 10, round( $lsr * 25 ) );
                $awl = $stats['words'] > 0 ? $stats['chars'] / $stats['words'] : 0;
                $p3  = ( $awl > 6 ) ? (int) min( 5, ceil( ( $awl - 6 ) * 5 ) ) : 0;
                $read = max( 0, self::W_READ - $p1 - $p2 - $p3 );

                $res['parts']['read'] = array(
                        'earned' => (int) round( $read ),
                        'max'    => self::W_READ,
                        'asl'    => round( $asl, 1 ),
                        'long'   => $stats['long_sentences'],
                );

                $read_ok = ( $read >= self::W_READ - 8 );
                $res['checks'][] = array(
                        'key'    => 'read',
                        'label'  => 'خوانایی (طول جمله‌ها)',
                        'state'  => $read_ok ? 'ok' : ( $read >= self::W_READ - 16 ? 'warn' : 'bad' ),
                        'detail' => 'میانگین هر جمله ' . number_test( round( $asl ) ) . ' واژه؛ ' . number_test( $stats['long_sentences'] ) . ' جملهٔ بلند (بیش از ۲۵ واژه)',
                );
                if ( ! $read_ok ) {
                        $res['tips'][] = 'جمله‌های بلند را بشکنید؛ میانگین فعلی ' . number_test( round( $asl ) ) . ' واژه در هر جمله است (مطلوب: زیر ۱۸ واژه).';
                }

                /* ---------------- ۳) پاراگراف‌بندی و ساختار (۱۵ امتیاز) ---------------- */
                $headings = self::headings_of( $html );
                $p_longp  = min( 6, $stats['long_paragraphs'] * 2 );
                $p_wall   = ( $stats['words'] >= 150 && $stats['paragraphs'] < 2 ) ? 4 : 0;
                $p_noh    = ( $stats['words'] >= 300 && 0 === count( $headings ) ) ? 3 : 0;
                $struct   = max( 0, self::W_STRUCT - $p_longp - $p_wall - $p_noh );

                $res['parts']['struct'] = array(
                        'earned'  => (int) round( $struct ),
                        'max'     => self::W_STRUCT,
                        'paras'   => $stats['paragraphs'],
                        'longpar' => $stats['long_paragraphs'],
                        'heads'   => count( $headings ),
                );

                $struct_ok = ( $struct >= self::W_STRUCT - 4 );
                $res['checks'][] = array(
                        'key'    => 'struct',
                        'label'  => 'پاراگراف‌بندی و ساختار',
                        'state'  => $struct_ok ? 'ok' : ( $struct >= self::W_STRUCT - 8 ? 'warn' : 'bad' ),
                        'detail' => number_test( $stats['paragraphs'] ) . ' پاراگراف، ' . number_test( count( $headings ) ) . ' عنوان داخلی'
                                . ( $stats['long_paragraphs'] ? '، ' . number_test( $stats['long_paragraphs'] ) . ' پاراگراف خیلی بلند' : '' ),
                );
                if ( ! $struct_ok ) {
                        if ( $stats['long_paragraphs'] ) {
                                $res['tips'][] = 'پاراگراف‌های بیش از ۱۰۰ واژه را به دو یا سه پاراگراف کوچک‌تر بشکنید.';
                        }
                        if ( $p_wall ) {
                                $res['tips'][] = 'متن شما تقریباً یک‌تکه است؛ هر ایده را در پاراگراف جداگانه بنویسید.';
                        }
                        if ( $p_noh ) {
                                $res['tips'][] = 'برای متن‌های بلند، از عنوان‌های داخلی (H2/H3) استفاده کنید تا خواندن راحت‌تر شود.';
                        }
                }

                /* ---------------- ۴) سئوی کلمه کلیدی (۱۵ امتیاز) ---------------- */
                $kw_n = self::norm( $focus_kw );
                $has_kw = ( '' !== $kw_n );

                if ( $has_kw ) {
                        $plain_n = self::norm( $plain );
                        $occ     = substr_count( $plain_n, $kw_n );
                        $density = $occ * 100 / max( 1, $stats['words'] );

                        $title_n = self::norm( $title );
                        $first_n = self::norm( $stats['first_para'] );

                        $in_title = ( '' !== $title_n && false !== strpos( $title_n, $kw_n ) );
                        $in_first = ( '' !== $first_n && false !== strpos( $first_n, $kw_n ) );
                        $in_head  = false;
                        foreach ( $headings as $h ) {
                                if ( false !== strpos( self::norm( $h ), $kw_n ) ) { $in_head = true; break; }
                        }

                        if ( 0 === $occ )            { $p_den = self::W_SEO; $den_ok = 'bad'; }
                        elseif ( $density < 0.4 )    { $p_den = self::W_SEO - 3; $den_ok = 'warn'; }
                        elseif ( $density <= 2.5 )   { $p_den = 0; $den_ok = 'ok'; }
                        else                         { $p_den = self::W_SEO - 3; $den_ok = 'warn'; }

                        $seo = max( 0, self::W_SEO - $p_den - ( $in_title ? 0 : 4 ) - ( $in_first ? 0 : 2 ) - ( $in_head ? 0 : 2 ) );

                        $res['parts']['seo'] = array(
                                'earned'  => (int) round( $seo ),
                                'max'     => self::W_SEO,
                                'occ'     => $occ,
                                'density' => round( $density, 2 ),
                                'in_title'=> $in_title,
                                'in_first'=> $in_first,
                                'in_head' => $in_head,
                        );

                        $res['checks'][] = array(
                                'key'    => 'kw_title',
                                'label'  => 'کلمه کلیدی در عنوان',
                                'state'  => $in_title ? 'ok' : 'bad',
                                'detail' => $in_title ? 'کلمه کلیدی در عنوان نوشته آمده است' : 'کلمه کلیدی در عنوان نوشته نیست',
                        );
                        if ( ! $in_title ) { $res['tips'][] = 'کلمه کلیدی «' . $focus_kw . '» را در عنوان نوشته بیاورید.'; }

                        $res['checks'][] = array(
                                'key'    => 'kw_first',
                                'label'  => 'کلمه کلیدی در پاراگراف نخست',
                                'state'  => $in_first ? 'ok' : 'warn',
                                'detail' => $in_first ? 'کلمه کلیدی در پاراگراف اول آمده است' : 'کلمه کلیدی در پاراگراف اول دیده نمی‌شود',
                        );
                        if ( ! $in_first ) { $res['tips'][] = 'ترجیحاً کلمه کلیدی را در جمله‌های ابتدایی متن هم به کار ببرید.'; }

                        $res['checks'][] = array(
                                'key'    => 'kw_head',
                                'label'  => 'کلمه کلیدی در عنوان‌های داخلی',
                                'state'  => $in_head ? 'ok' : 'warn',
                                'detail' => $in_head ? 'حداقل یکی از عنوان‌های H2/H3 کلمه کلیدی دارد' : 'کلمه کلیدی در هیچ عنوان داخلی نیست',
                        );
                        if ( ! $in_head ) { $res['tips'][] = 'در یکی از عنوان‌های داخلی (H2 یا H3) از کلمه کلیدی استفاده کنید.'; }

                        $res['checks'][] = array(
                                'key'    => 'kw_density',
                                'label'  => 'تراکم کلمه کلیدی',
                                'state'  => $den_ok,
                                'detail' => 0 === $occ
                                        ? 'کلمه کلیدی اصلاً در متن نیست'
                                        : number_test( $occ ) . ' بار در متن (تراکم ≈ ٪' . number_test( round( $density, 1 ) ) . '؛ مطلوب: ٪۰٫۴ تا ٪۲٫۵)',
                        );
                        if ( 'ok' !== $den_ok ) {
                                $res['tips'][] = ( 0 === $occ )
                                        ? 'کلمه کلیدی در متن استفاده نشده است؛ طبیعی و بدون تکرارِ زننده به کار ببرید.'
                                        : 'تراکم کلمه کلیدی را در بازهٔ ٪۰٫۴ تا ٪۲٫۵ نگه دارید؛ تکرار بیش از حد، ضد سئو است.';
                        }
                } else {
                        $seo = null;
                        $res['checks'][] = array(
                                'key'    => 'kw_na',
                                'label'  => 'سئوی کلمه کلیدی',
                                'state'  => 'na',
                                'detail' => 'برای تحلیل سئو، کلمه کلیدی را در کادر بالا وارد کنید',
                        );
                }

                /* ---------------- جمع امتیاز ---------------- */
                if ( $has_kw ) {
                        $total = $ortho + $read + $struct + $seo;
                } else {
                        $total = ( $ortho + $read + $struct ) / ( self::W_ORTHO + self::W_READ + self::W_STRUCT ) * 100;
                }
                $score = (int) max( 5, min( 100, round( $total ) ) );

                list( $res['grade_key'], $res['grade'] ) = self::grade_of( $score );
                $res['score'] = $score;

                return $res;
        }

        /** برچسب و کلید درجه از روی امتیاز. */
        public static function grade_of( $score ) {
                $score = (int) $score;
                if ( $score >= 85 ) { return array( 'great', 'عالی' ); }
                if ( $score >= 70 ) { return array( 'good', 'خوب' ); }
                if ( $score >= 50 ) { return array( 'fair', 'نیازمند بهبود' ); }
                return array( 'poor', 'ضعیف' );
        }

        /* ================================================================== *
         * ابزارهای تحلیل متن (خالص)
         * ================================================================== */

        /** تبدیل HTML به متن ساده؛ مرز بلوک‌ها با \n مشخص می‌شود. */
        private static function to_plain( $html ) {
                $h = preg_replace( '/<(script|style|pre|code)\b[^>]*>.*?<\/\1>/is', ' ', (string) $html );
                $h = preg_replace( '/<br\s*\/?>/i', "\n", $h );
                $h = preg_replace( '/<\/(p|div|h[1-6]|li|tr|blockquote|figure|section|article)>/i', "\n", $h );
                $h = strip_tags( $h );
                $h = html_entity_decode( $h, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
                $h = str_replace( "\xC2\xA0", ' ', $h ); // &nbsp; واقعی
                $h = preg_replace( '/[ \t]+/', ' ', $h );
                $h = preg_replace( '/\n{2,}/', "\n", $h );
                return trim( $h );
        }

        /** شمارش واژه‌های یک رشته (توکن‌های دارای حرف/عدد). */
        private static function count_words( $s ) {
                $n = 0;
                foreach ( preg_split( '/\s+/u', trim( (string) $s ) ) as $t ) {
                        if ( '' === $t ) { continue; }
                        $t = preg_replace( '/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/u', '', $t );
                        if ( '' !== $t && preg_match( '/[\p{L}\p{N}]/u', $t ) ) { $n++; }
                }
                return $n;
        }

        /** آمار کلی متن ساده. */
        private static function text_stats( $plain ) {
                $stats = array(
                        'words' => 0, 'chars' => 0, 'sentences' => 0, 'paragraphs' => 0,
                        'long_sentences' => 0, 'long_paragraphs' => 0,
                        'reading_min' => 0, 'first_para' => '',
                );
                $plain = trim( (string) $plain );
                if ( '' === $plain ) { return $stats; }

                $lines = preg_split( '/\n+/u', $plain );
                $sent_words = array();
                $total_words = 0;
                $total_chars = 0;

                foreach ( $lines as $line ) {
                        $line = trim( (string) $line );
                        if ( '' === $line ) { continue; }

                        $wc = self::count_words( $line );
                        if ( $wc <= 0 ) { continue; }

                        if ( '' === $stats['first_para'] ) { $stats['first_para'] = $line; }
                        $stats['paragraphs']++;
                        if ( $wc > 100 ) { $stats['long_paragraphs']++; }
                        $total_words += $wc;
                        if ( preg_match_all( '/[\p{L}\p{N}]/u', $line, $mc ) ) { $total_chars += count( $mc[0] ); }

                        foreach ( preg_split( '/[.!؟?…؛:]+/u', $line ) as $seg ) {
                                $seg = trim( (string) $seg );
                                if ( '' === $seg ) { continue; }
                                $swc = self::count_words( $seg );
                                if ( $swc >= 3 ) { $sent_words[] = $swc; }
                        }
                }

                $stats['words'] = $total_words;
                $stats['chars'] = $total_chars;
                $stats['sentences']      = count( $sent_words );
                $stats['long_sentences'] = count( array_filter( $sent_words, function ( $n ) { return $n > 25; } ) );
                $stats['reading_min']    = max( 1, (int) ceil( $total_words / 200 ) );

                return $stats;
        }

        /** متن عنوان‌های داخلی HTML (h1..h6). */
        private static function headings_of( $html ) {
                $out = array();
                if ( preg_match_all( '/<h[1-6][^>]*>(.*?)<\/h[1-6]>/is', (string) $html, $m ) ) {
                        foreach ( $m[1] as $inner ) {
                                $t = trim( strip_tags( html_entity_decode( $inner, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
                                if ( '' !== $t ) { $out[] = $t; }
                        }
                }
                return $out;
        }

        /** یکسان‌سازی برای تطبیق کلمه کلیدی: عربی→فارسی، نیم‌فاصله→فاصله، حذف جهت‌ها. */
        private static function norm( $s ) {
                $s = strtr( (string) $s, array(
                        'ي' => 'ی', 'ك' => 'ک', 'ة' => 'ه', 'أ' => 'ا', 'إ' => 'ا', 'ٱ' => 'ا',
                        '٠' => '۰', '١' => '۱', '٢' => '۲', '٣' => '۳', '٤' => '۴',
                        '٥' => '۵', '٦' => '۶', '٧' => '۷', '٨' => '۸', '٩' => '۹',
                ) );
                $s = str_replace( "\u{200C}", ' ', $s );
                $s = preg_replace( '/[\x{200E}\x{200F}\x{0640}]/u', '', $s );
                $s = preg_replace( '/[\s\x{00A0}]+/u', ' ', $s );
                return trim( mb_strtolower( trim( $s ) ) );
        }

        /* ================================================================== *
         * ذخیره امتیاز
         * ================================================================== */

        /** محاسبه و ذخیرهٔ امتیاز یک نوشته (از محتوای موجود در دیتابیس). */
        public static function store( $post_id ) {
                $post = get_post( $post_id );
                if ( ! $post || ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) { return null; }
                if ( in_array( $post->post_status, array( 'trash', 'auto-draft' ), true ) ) { return null; }

                $kw  = get_post_meta( $post->ID, self::META_KW, true );
                $res = self::analyze( $post->post_content, null, get_the_title( $post ), is_string( $kw ) ? $kw : '' );

                update_post_meta( $post->ID, self::META_SCORE, array(
                        'score'      => $res['score'],
                        'grade'      => $res['grade'],
                        'grade_key'  => $res['grade_key'],
                        'words'      => $res['stats']['words'],
                        'issues'     => $res['issues'],
                        'checked_at' => current_time( 'mysql' ),
                ) );
                return $res;
        }

        /* ================================================================== *
         * AJAX
         * ================================================================== */

        public static function ajax_score() {
                if ( ! check_ajax_referer( 'virastar_ajax', 'nonce', false ) ) {
                        wp_send_json_error( array( 'message' => 'نشست منقضی شده؛ صفحه را تازه‌سازی کنید.' ), 403 );
                }
                if ( ! current_user_can( 'edit_posts' ) ) {
                        wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز است.' ), 403 );
                }

                $post_id = isset( $_POST['post_id'] ) ? absint( $_POST['post_id'] ) : 0;
                $content = isset( $_POST['content'] ) ? (string) wp_unslash( $_POST['content'] ) : '';
                $title   = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
                $kw_raw  = isset( $_POST['focus_kw'] ) ? sanitize_text_field( wp_unslash( $_POST['focus_kw'] ) ) : null;

                $post = $post_id ? get_post( $post_id ) : null;
                if ( $post_id && ! $post ) {
                        wp_send_json_error( array( 'message' => 'نوشته پیدا نشد.' ), 404 );
                }
                if ( $post && ! current_user_can( 'edit_post', $post_id ) ) {
                        wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز است.' ), 403 );
                }

                /* ذخیرهٔ کلمه کلیدی (ارسال صریحِ فیلد؛ رشتهٔ خالی = حذف) */
                if ( null !== $kw_raw && $post_id ) {
                        if ( '' === trim( $kw_raw ) ) {
                                delete_post_meta( $post_id, self::META_KW );
                        } else {
                                update_post_meta( $post_id, self::META_KW, trim( $kw_raw ) );
                        }
                }

                $kw    = $post_id ? (string) get_post_meta( $post_id, self::META_KW, true ) : '';
                $html  = ( '' !== trim( $content ) ) ? $content : ( $post ? $post->post_content : '' );
                $t     = ( '' !== $title ) ? $title : ( $post ? get_the_title( $post ) : '' );
                $res   = self::analyze( $html, null, $t, $kw );

                if ( $post_id && ! $res['too_short'] ) {
                        update_post_meta( $post_id, self::META_SCORE, array(
                                'score'      => $res['score'],
                                'grade'      => $res['grade'],
                                'grade_key'  => $res['grade_key'],
                                'words'      => $res['stats']['words'],
                                'issues'     => $res['issues'],
                                'checked_at' => current_time( 'mysql' ),
                        ) );
                }

                wp_send_json_success( array(
                        'score'     => $res['score'],
                        'grade'     => $res['grade'],
                        'grade_key' => $res['grade_key'],
                        'html'      => self::result_html( $res, ( '' !== trim( $content ) ) ? 'بر اساس متنِ فعلی ویرایشگر' : 'بر اساس آخرین نسخهٔ ذخیره‌شده' ),
                ) );
        }

        /* ================================================================== *
         * متاباکس ویرایشگر
         * ================================================================== */

        public static function register_metabox() {
                foreach ( array( 'post', 'page' ) as $pt ) {
                        add_meta_box( 'virastar-score-box', 'ویراستار | کیفیت محتوا و سئو', array( __CLASS__, 'metabox_html' ), $pt, 'normal', 'high' );
                }
        }

        public static function metabox_html( $post ) {
                $kw   = get_post_meta( $post->ID, self::META_KW, true );
                $data = get_post_meta( $post->ID, self::META_SCORE, true );
                $auto = ( ! is_array( $data ) || ! isset( $data['score'] ) ) ? '1' : '0';
                ?>
                <div id="virastar-scorebox" class="vxs-box" data-post="<?php echo esc_attr( $post->ID ); ?>" data-auto="<?php echo esc_attr( $auto ); ?>" dir="rtl">
                        <div class="vxs-kw-row">
                                <label for="vx-kw">کلمه کلیدی سئو:</label>
                                <input type="text" id="vx-kw" value="<?php echo esc_attr( is_string( $kw ) ? $kw : '' ); ?>" placeholder="مثلاً: خرید قالب وردپرس">
                                <button type="button" class="button button-primary" id="vx-score-run">ذخیره و بررسی</button>
                                <span class="vxs-kw-hint">امتیاز کیفیت، خوانایی و سئو را همین‌جا می‌بینید؛ محاسبهٔ کامل آفلاین است.</span>
                        </div>
                        <div id="vx-score-result" class="vxs-result">
                                <?php
                                if ( is_array( $data ) && isset( $data['score'] ) ) {
                                        if ( null === $data['score'] ) {
                                                echo '<p class="vxs-empty">متن این نوشته هنوز برای امتیازدهی کوتاه است.</p>';
                                        } else {
                                                echo self::badge_html( (int) $data['score'], (string) $data['grade'] );
                                                echo '<p class="vxs-updated">آخرین بررسی: ' . esc_html( mysql2date( 'Y/m/d H:i', $data['checked_at'] ) ) . ' — برای به‌روزرسانی، دکمهٔ «ذخیره و بررسی» را بزنید.</p>';
                                        }
                                } else {
                                        echo '<p class="vxs-empty">برای محاسبهٔ امتیاز، دکمهٔ «ذخیره و بررسی» را بزنید.</p>';
                                }
                                ?>
                        </div>
                </div>
                <?php
        }

        /** نشان امتیاز (دایرهٔ رنگی). */
        private static function badge_html( $score, $grade ) {
                list( $key, $glabel ) = self::grade_of( $score );
                return '<div class="vxs-dial ' . esc_attr( 'g-' . $key ) . '" style="--p:' . (int) $score . '">'
                        . '<span class="vxs-dial-num">' . esc_html( number_format_i18n( $score ) ) . '</span>'
                        . '<span class="vxs-dial-lbl">از ۱۰۰ — ' . esc_html( $glabel ) . '</span>'
                        . '</div>';
        }

        /** HTML کامل نتیجه (سرویس‌رندر؛ JS فقط تزریق می‌کند). */
        public static function result_html( $res, $source = '' ) {
                if ( ! is_array( $res ) || $res['too_short'] ) {
                        return '<p class="vxs-empty">متن برای امتیازدهی کوتاه است (حداقل ۱۵ واژه).</p>';
                }

                $s     = $res['stats'];
                $parts = $res['parts'];

                $html  = '<div class="vxs-head">';
                $html .= self::badge_html( (int) $res['score'], $res['grade'] );
                $html .= '<ul class="vxs-parts">';
                foreach ( array( 'ortho' => 'نگارش فارسی', 'read' => 'خوانایی', 'struct' => 'ساختار' ) as $pk => $pl ) {
                        if ( ! isset( $parts[ $pk ] ) ) { continue; }
                        $html .= '<li><span class="vxs-part-lbl">' . esc_html( $pl ) . '</span>'
                                . '<span class="vxs-part-bar"><i style="width:' . min( 100, round( $parts[ $pk ]['earned'] / max( 1, $parts[ $pk ]['max'] ) * 100 ) ) . '%"></i></span>'
                                . '<span class="vxs-part-num">' . esc_html( number_format_i18n( $parts[ $pk ]['earned'] ) ) . '/' . esc_html( number_format_i18n( $parts[ $pk ]['max'] ) ) . '</span></li>';
                }
                if ( isset( $parts['seo'] ) ) {
                        $html .= '<li><span class="vxs-part-lbl">سئو</span>'
                                . '<span class="vxs-part-bar"><i style="width:' . min( 100, round( $parts['seo']['earned'] / max( 1, $parts['seo']['max'] ) * 100 ) ) . '%"></i></span>'
                                . '<span class="vxs-part-num">' . esc_html( number_format_i18n( $parts['seo']['earned'] ) ) . '/' . esc_html( number_format_i18n( $parts['seo']['max'] ) ) . '</span></li>';
                } else {
                        $html .= '<li class="vxs-part-na"><span class="vxs-part-lbl">سئو</span><span class="vxs-part-num">کلمه کلیدی وارد نشده</span></li>';
                }
                $html .= '</ul></div>';

                $html .= '<ul class="vxs-stats">';
                $html .= '<li><b>' . esc_html( number_format_i18n( $s['words'] ) ) . '</b> واژه</li>';
                $html .= '<li>زمان مطالعه <b>~' . esc_html( number_format_i18n( $s['reading_min'] ) ) . '</b> دقیقه</li>';
                $html .= '<li><b>' . esc_html( number_format_i18n( $s['sentences'] ) ) . '</b> جمله</li>';
                $html .= '<li><b>' . esc_html( number_format_i18n( $s['paragraphs'] ) ) . '</b> پاراگراف</li>';
                if ( isset( $parts['read'] ) ) {
                        $html .= '<li>میانگین جمله <b>' . esc_html( number_format_i18n( $parts['read']['asl'] ) ) . '</b> واژه</li>';
                }
                if ( $res['issues'] ) {
                        $html .= '<li class="vxs-issues"><b>' . esc_html( number_format_i18n( $res['issues'] ) ) . '</b> مورد نگارشی</li>';
                }
                $html .= '</ul>';

                $html .= '<ul class="vxs-checks">';
                foreach ( $res['checks'] as $c ) {
                        $ico = 'ok' === $c['state'] ? '✓' : ( 'bad' === $c['state'] ? '✕' : ( 'warn' === $c['state'] ? '!' : '–' ) );
                        $html .= '<li class="vxs-check is-' . esc_attr( $c['state'] ) . '"><span class="vxs-check-ico">' . esc_html( $ico ) . '</span>'
                                . '<span class="vxs-check-lbl">' . esc_html( $c['label'] ) . '</span>'
                                . '<span class="vxs-check-dtl">' . esc_html( $c['detail'] ) . '</span></li>';
                }
                $html .= '</ul>';

                if ( ! empty( $res['tips'] ) ) {
                        $html .= '<div class="vxs-tips"><div class="t">پیشنهادهای بهبود</div><ul>';
                        foreach ( $res['tips'] as $tip ) {
                                $html .= '<li>' . esc_html( $tip ) . '</li>';
                        }
                        $html .= '</ul></div>';
                }

                if ( $source ) {
                        $html .= '<p class="vxs-source">' . esc_html( $source ) . ' — امتیاز پس از ذخیرهٔ نوشته هم خودکار به‌روز می‌شود.</p>';
                }

                return $html;
        }

        /* ================================================================== *
         * ستون فهرست نوشته‌ها
         * ================================================================== */

        public static function columns_head( $cols ) {
                $new = array();
                $added = false;
                foreach ( (array) $cols as $k => $v ) {
                        $new[ $k ] = $v;
                        if ( 'title' === $k ) { $new['vx_score'] = 'کیفیت محتوا'; $added = true; }
                }
                if ( ! $added ) { $new['vx_score'] = 'کیفیت محتوا'; }
                return $new;
        }

        public static function columns_cell( $col, $post_id ) {
                if ( 'vx_score' !== $col ) { return; }
                $d = get_post_meta( $post_id, self::META_SCORE, true );
                if ( ! is_array( $d ) || ! isset( $d['score'] ) || null === $d['score'] ) {
                        echo '<span class="vx-score-badge is-none">—</span>';
                        return;
                }
                $score = (int) $d['score'];
                list( $key, $glabel ) = self::grade_of( $score );
                $cls = ( 'great' === $key || 'good' === $key ) ? 's-high' : ( 'fair' === $key ? 's-mid' : 's-low' );
                echo '<span class="vx-score-badge ' . esc_attr( $cls ) . '" title="' . esc_attr( $glabel ) . '">' . esc_html( number_format_i18n( $score ) ) . '</span>'
                        . '<span class="vx-score-grade">' . esc_html( $glabel ) . '</span>';
        }

        /** استایل نشان امتیاز در فهرست نوشته‌ها (admin.css آنجا لود نمی‌شود). */
        public static function list_styles() {
                echo '<style>
                        .column-vx_score{width:86px;white-space:nowrap}
                        .vx-score-badge{display:inline-block;min-width:34px;text-align:center;padding:2px 7px;border-radius:999px;font-weight:700;font-size:12.5px;line-height:1.7}
                        .vx-score-badge.s-high{background:#ecfdf5;color:#15803d;border:1px solid #a7f3d0}
                        .vx-score-badge.s-mid{background:#fffbeb;color:#b45309;border:1px solid #fde68a}
                        .vx-score-badge.s-low{background:#fff1f2;color:#be123c;border:1px solid #fecdd3}
                        .vx-score-badge.is-none{background:#f1f5f9;color:#94a3b8;border:1px solid #e2e8f0}
                        .vx-score-grade{display:block;font-size:10.5px;color:#64748b;margin-top:1px}
                </style>';
        }

        /* ================================================================== *
         * داشبورد: بخش سلامت محتوا
         * ================================================================== */

        /** میانگین امتیاز و توزیع درجه‌ها بر اساس نوشته‌های اسکن‌شدهٔ اخیر. */
        public static function health_snapshot() {
                if ( ! class_exists( 'Virastar_Admin' ) ) { return null; }
                $ids = array();
                foreach ( Virastar_Admin::get_log() as $row ) {
                        if ( ! empty( $row['id'] ) ) { $ids[] = (int) $row['id']; }
                }
                $ids = array_values( array_unique( $ids ) );
                if ( ! $ids ) { return null; }

                $dist = array( 'great' => 0, 'good' => 0, 'fair' => 0, 'poor' => 0 );
                $scores = array();
                $per_post = array();

                foreach ( $ids as $pid ) {
                        $d = get_post_meta( $pid, self::META_SCORE, true );
                        if ( ! is_array( $d ) || ! isset( $d['score'] ) || null === $d['score'] ) { continue; }
                        $s = (int) $d['score'];
                        $scores[] = $s;
                        list( $key ) = self::grade_of( $s );
                        if ( isset( $dist[ $key ] ) ) { $dist[ $key ]++; }
                        $per_post[ $pid ] = $s;
                }

                if ( ! $scores ) { return null; }
                asort( $per_post );
                $worst = array_slice( $per_post, 0, 5, true );

                return array(
                        'avg'    => (int) round( array_sum( $scores ) / count( $scores ) ),
                        'count'  => count( $scores ),
                        'total'  => count( $ids ),
                        'dist'   => $dist,
                        'worst'  => $worst,
                );
        }
}

/**
 * شمارش با ارقام فارسی؛ در وردپرس از number_format_i18n استفاده می‌شود و
 * در محیط تست (خارج از وردپرس) نسخهٔ سادهٔ همین تابع به کار می‌رود.
 */
if ( ! function_exists( 'number_test' ) ) {
        function number_test( $n ) {
                if ( function_exists( 'number_format_i18n' ) ) { return number_format_i18n( $n ); }
                $fa = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );
                return str_replace( range( 0, 9 ), $fa, (string) $n );
        }
}
