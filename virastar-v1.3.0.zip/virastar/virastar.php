<?php
/**
 * Plugin Name: ویراستار | نگارشیار متن فارسی
 * Description: اصلاح خودکار نیم‌فاصله، حروف عربی، فاصله‌گذاری، نشانه‌گذاری و اعداد در متن فارسی وردپرس + اسکن و اصلاح انبوه + امتیاز کیفیت محتوا و سئوی فارسی.
 * Version: 1.3.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: SiteBan
 * Text Domain: virastar
 */

if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

define( 'VIRASTAR_VERSION', '1.3.0' );
define( 'VIRASTAR_FILE', __FILE__ );
define( 'VIRASTAR_PATH', plugin_dir_path( __FILE__ ) );
define( 'VIRASTAR_URL', plugin_dir_url( __FILE__ ) );

/* ------------------------------------------------------------------------- *
 * مستندسازی هش لایسنس
 *
 * ثابت VIRASTAR_LICENSE_SHA1 هش فایل لایسنس رسمی این محصول است و صرفاً
 * برای هم‌راستایی با کد بررسی لایسنس در virastar-pro.php نگه داشته می‌شود؛
 * در این نسخه اثر اجرایی ندارد.
 * ---------------------------------------------------------------------- */

define( 'VIRASTAR_LICENSE_SHA1', '5e315f6cab620892d7d24c71e0d3853010538ab8' );

/* ------------------------------------------------------------------------- *
 * نسخهٔ ۱.۳.۰ — همهٔ امکانات بدون نیاز به لایسنس
 *
 *   • همهٔ فایل‌های این بسته متنی و باز هستند و روی هر هاستی بدون لودر
 *     ionCube اجرا می‌شوند.
 *   • همهٔ امکانات (اسکن انبوه، اصلاح انبوه، خروجی CSV، اصلاح خودکار هنگام
 *     ذخیره، امتیاز کیفیت محتوا و سئوی فارسی) بدون نیاز به لایسنس فعال
 *     می‌شوند (ثابت VIRASTAR_OPEN_MODE).
 *   • بلوک بررسی لایسنس داخل virastar-pro.php دست‌نخورده مانده و در نبود
 *     فایل لایسنس، هیچ کاری انجام نمی‌دهد؛ فعال‌سازی همهٔ امکانات پس از آن
 *     (اولویت ۶) اجرا می‌شود.
 * ---------------------------------------------------------------------- */
define( 'VIRASTAR_OPEN_MODE', true );

/* فایل لایسنس فقط در بسته‌های محافظت‌شده (ionCube) قرار دارد؛ در این بسته
 * بارگذاری نمی‌شود تا روی هر هاستی — حتی بدون لودر ionCube — بدون خطا
 * اجرا شود. بلوک بررسی لایسنس در virastar-pro.php با class_exists() نبودن
 * کلاس را به‌آرامی عبور می‌دهد. */
if ( ! defined( 'VIRASTAR_OPEN_MODE' ) || ! VIRASTAR_OPEN_MODE ) {
        $licenseFilePath = __DIR__ . DIRECTORY_SEPARATOR . 'Virastar_License.php';
        if ( is_file( $licenseFilePath ) ) {
                require_once $licenseFilePath;
        }
        unset( $licenseFilePath );
}

/* هسته رایگان افزونه */
require_once VIRASTAR_PATH . 'includes/class-virastar-engine.php';
require_once VIRASTAR_PATH . 'includes/class-virastar-admin.php';
require_once VIRASTAR_PATH . 'includes/class-virastar-score.php';

/*
 * فایل امکانات لایسنس‌دار (نسخه حرفه‌ای).
 * این فایل همراه با کد بررسی لایسنس RTL برای محافظت ارسال می‌شود؛
 * بدون فایل لایسنس، افزونه در حالت رایگان و بدون امکانات حرفه‌ای اجرا می‌شود.
 */
require_once VIRASTAR_PATH . 'virastar-pro.php';

/* نسخهٔ باز: فعال‌سازی همهٔ امکانات بدون نیاز به لایسنس.
 * activate() خودش idempotent است؛ اگر لایسنس رسمی در اولویت ۵ فعال شده
 * باشد، این فراخوانی هیچ اثر اضافه‌ای ندارد. */
if ( defined( 'VIRASTAR_OPEN_MODE' ) && VIRASTAR_OPEN_MODE ) {
        add_action( 'plugins_loaded', array( 'Virastar_Pro', 'activate' ), 6 );
}

register_activation_hook( __FILE__, array( 'Virastar_Admin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Virastar_Admin', 'deactivate' ) );
add_action( 'plugins_loaded', array( 'Virastar_Admin', 'boot' ) );
add_action( 'plugins_loaded', array( 'Virastar_Score', 'boot' ) );
