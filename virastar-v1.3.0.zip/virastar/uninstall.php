<?php
/**
 * Virastar uninstall: remove options and post meta on complete deletion.
 * (Deactivation alone keeps all data, by design.)
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'virastar_options' );
delete_option( 'virastar_log' );

global $wpdb;
$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = '_virastar_report'" );
$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = '_virastar_score'" );
$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = '_virastar_focus_kw'" );
