/**
 * Virastar editor integration — works with BOTH the Classic editor
 * (TinyMCE/textarea) and the Block editor (Gutenberg) without a build step.
 *
 * Flow: button click -> grab current content -> AJAX scan -> modal report
 * -> "apply" writes the fixed text back to the active editor.
 */
(function () {
        'use strict';

        var D = window.VirastarData || {};
        var $ = window.jQuery;

        /* ---------------- overlay modal ---------------- */
        function ensureModal() {
                if (document.getElementById('virastar-modal-bg')) { return; }
                var bg = document.createElement('div');
                bg.id = 'virastar-modal-bg';
                bg.className = 'virastar-modal-bg';
                var box = document.createElement('div');
                box.id = 'virastar-modal';
                box.className = 'virastar-modal';
                box.setAttribute('dir', 'rtl');
                document.body.appendChild(bg);
                document.body.appendChild(box);

                bg.addEventListener('click', function () { close(); });
        }

        function close() {
                var bg = document.getElementById('virastar-modal-bg');
                var box = document.getElementById('virastar-modal');
                if (bg) { bg.style.display = 'none'; }
                if (box) { box.style.display = 'none'; }
        }

        function esc(s) {
                return String(s == null ? '' : s)
                        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
                        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        }

        function renderReport(data, applyCb) {
                ensureModal();
                var box = document.getElementById('virastar-modal');
                var bg = document.getElementById('virastar-modal-bg');
                var labels = D.labels || {};

                var html = ''
                        + '<div class="vx-modal-head">'
                        +   '<span class="mico"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg></span>'
                        +   '<div><h2>گزارش ویراستاری</h2><div class="msub">بررسی نگارشی متن شما</div></div>'
                        +   '<button type="button" class="vx-modal-close" id="virastar-close" aria-label="بستن">✕</button>'
                        + '</div>'
                        + '<div class="vx-modal-body">';

                if (!data.changed && (data.total || 0) === 0) {
                        html += ''
                                + '<div class="vx-clean">'
                                +   '<div class="ring"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg></div>'
                                +   '<h3>متن شما سالم است!</h3>'
                                +   '<p>از نظر نگارش فارسی هیچ مورد قابل اصلاحی پیدا نشد. ✔</p>'
                                + '</div>';
                } else {
                        var total = parseInt(data.total, 10) || 0;
                        html += '<div class="vx-total' + (total ? '' : ' warm') + '">'
                                + '<span class="n">' + esc(total) + '</span>'
                                + '<span>' + (total ? 'مورد نگارشی قابل اصلاح پیدا شد' : 'متن اصلاح جزئی نیاز دارد') + '</span>'
                                + '</div>';

                        var counts = data.counts || {};
                        var samples = data.samples || {};
                        var chips = '';
                        var list = '';

                        for (var k in counts) {
                                if (!counts.hasOwnProperty(k) || !counts[k]) { continue; }
                                chips += '<span class="vx-chip">' + esc(labels[k] || k) + ' <span class="c">' + esc(counts[k]) + '</span></span>';

                                var s = samples[k] || [];
                                var rows = '';
                                for (var i = 0; i < s.length; i++) {
                                        rows += '<div class="virastar-sample"><span class="b">' + esc(s[i].before) + '</span>'
                                                + '<span class="arrow">⟵</span>'
                                                + '<span class="a">' + esc(s[i].after) + '</span></div>';
                                }
                                if (rows) {
                                        list += '<div class="vx-sample"><span class="vx-sample-title">' + esc(labels[k] || k) + '</span>' + rows + '</div>';
                                }
                        }

                        if (chips) { html += '<div class="vx-chips">' + chips + '</div>'; }
                        if (list)  { html += '<div class="vx-sample-list">' + list + '</div>'; }
                        if (!chips && !list) {
                                html += '<div class="virastar-sample">موردی برای اصلاح خودکار پیدا نشد.</div>';
                        }

                        var sug = data.suggestions || [];
                        if (sug.length) {
                                html += '<div class="vx-sug-box"><div class="t">'
                                        + '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
                                        + 'پیشنهادهای سبک نگارش</div><ul>';
                                for (var j = 0; j < sug.length; j++) {
                                        html += '<li>' + esc(sug[j]) + '</li>';
                                }
                                html += '</ul></div>';
                        }
                }

                html += '</div>'
                        + '<div class="vx-modal-foot">';
                if (data.changed) {
                        html += '<button type="button" class="vx-btn vx-btn-primary" id="virastar-apply">اعمال اصلاحات</button>';
                }
                html += '<button type="button" class="vx-btn vx-btn-ghost" id="virastar-close2">بستن</button>'
                        + '</div>';

                box.innerHTML = html;
                box.style.display = 'block';
                bg.style.display = 'block';

                var applyBtn = document.getElementById('virastar-apply');
                if (applyBtn) {
                        applyBtn.addEventListener('click', function () {
                                applyCb(data.fixed);
                                close();
                        });
                }
                document.getElementById('virastar-close').addEventListener('click', close);
                document.getElementById('virastar-close2').addEventListener('click', close);
        }

        /* ---------------- editor content access ---------------- */
        function isGutenberg() {
                return !!(window.wp && window.wp.data && window.wp.data.select && window.wp.data.select('core/editor'));
        }

        function getContent() {
                if (isGutenberg()) {
                        return window.wp.data.select('core/editor').getEditedPostContent() || '';
                }
                if (window.tinyMCE && window.tinyMCE.activeEditor && !window.tinyMCE.activeEditor.isHidden()) {
                        return window.tinyMCE.activeEditor.getContent() || '';
                }
                var ta = document.getElementById('content');
                return ta ? ta.value : '';
        }

        function setContent(fixed) {
                if (isGutenberg()) {
                        window.wp.data.dispatch('core/editor').editPost({ content: fixed });
                        return;
                }
                if (window.tinyMCE && window.tinyMCE.activeEditor && !window.tinyMCE.activeEditor.isHidden()) {
                        window.tinyMCE.activeEditor.setContent(fixed);
                }
                var ta = document.getElementById('content');
                if (ta) { ta.value = fixed; }
        }

        /* ---------------- AJAX scan ---------------- */
        function scan() {
                var content = getContent();
                if (!content || !content.replace(/\s|<[^>]*>/g, '').length) {
                        window.alert('متن خالی است؛ چیزی برای بررسی وجود ندارد.');
                        return;
                }

                $.post(D.ajax, {
                        action: 'virastar_scan_text',
                        nonce: D.nonce,
                        content: content
                }).done(function (res) {
                        if (res && res.success) {
                                renderReport(res.data, function (fixed) { setContent(fixed); });
                        } else {
                                window.alert((res && res.data && res.data.message) || 'خطا در بررسی متن.');
                        }
                }).fail(function () {
                        window.alert('ارتباط با سرور برقرار نشد.');
                });
        }

        window.VirastarUI = { scan: scan };

        /* ---------------- Gutenberg: More menu item ---------------- */
        if (window.wp && window.wp.plugins && window.wp.editPost && window.wp.element && window.wp.components) {
                var el = window.wp.element.createElement;
                var registerPlugin = window.wp.plugins.registerPlugin;
                var PluginMoreMenuItem = window.wp.editPost.PluginMoreMenuItem;

                registerPlugin('virastar-menu-item', {
                        render: function () {
                                return el(PluginMoreMenuItem, {
                                        icon: 'editor-spellcheck',
                                        onClick: function () { scan(); }
                                }, 'ویراستاری متن');
                        }
                });
        }

        /* ---------------- Classic: button binding ---------------- */
        $(function () {
                $(document).on('click', '#virastar-btn', function (e) {
                        e.preventDefault();
                        scan();
                });
        });
})();
