/**
 * Virastar bulk page: batch scanning and batch fixing with a graphical
 * progress bar (percentage + shine) and toast notifications.
 */
(function () {
	'use strict';

	var D = window.VirastarData || {};
	var $ = window.jQuery;

	function faNum(n) {
		return String(n).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[d]; });
	}

	function toast(msg, type) {
		var holder = document.getElementById('virastar-toasts');
		if (!holder) { return; }
		var el = document.createElement('div');
		el.className = 'vx-toast ' + (type || 'ok');
		var icon = 'ok' === type
			? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>'
			: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>';
		el.innerHTML = icon + '<span></span>';
		el.getElementsByTagName('span')[0].textContent = msg;
		holder.appendChild(el);
		window.setTimeout(function () {
			el.style.transition = 'opacity .3s';
			el.style.opacity = '0';
			window.setTimeout(function () { el.remove(); }, 320);
		}, 4200);
	}

	function idsFromTable() {
		var ids = [];
		$('#virastar-table tr[data-id]').each(function () {
			ids.push(parseInt($(this).data('id'), 10));
		});
		return ids;
	}

	function allPublishedIds() {
		return (window.VirastarBulk && window.VirastarBulk.ids) ? window.VirastarBulk.ids.slice(0) : idsFromTable();
	}

	function setBusy(busy) {
		$('#virastar-bulk-scan, #virastar-bulk-fix').prop('disabled', busy);
	}

	function setProgress(pct, text) {
		$('#virastar-progressbox').addClass('is-active');
		$('#virastar-progress .bar').css('width', pct + '%');
		$('#virastar-pct').text(faNum(pct) + '٪');
		if (text) {
			$('#virastar-status').show().text(text);
		}
	}

	function runBatches(ids, action, batch, doneLabel, finish) {
		var total = ids.length;
		var done = 0;
		var failures = 0;

		if (!total) {
			toast('چیزی برای پردازش پیدا نشد؛ اول اسکن انبوه را اجرا کنید.', 'err');
			return;
		}

		setBusy(true);

		function next() {
			if (!ids.length) {
				setProgress(100, 'پایان یافت: ' + doneLabel + ' (' + done + ' مطلب' + (failures ? '، ' + failures + ' خطا' : '') + ')');
				toast(doneLabel + ' انبوه کامل شد ✔ (' + faNum(done) + ' مطلب)', failures ? 'err' : 'ok');
				setBusy(false);
				if (finish) { finish(); }
				return;
			}
			var chunk = ids.splice(0, batch);
			$.post(D.ajax, {
				action: action,
				nonce: D.nonce,
				ids: chunk.join(',')
			}).done(function (res) {
				if (res && res.success) {
					done += (res.data.done || []).length;
				} else {
					failures++;
				}
			}).fail(function () {
				failures++;
			}).always(function () {
				setProgress(Math.round(((total - ids.length) / total) * 100), 'پردازش ' + faNum(total - ids.length) + ' از ' + faNum(total) + ' مطلب…');
				next();
			});
		}
		next();
	}

	$(function () {
		$(document).on('click', '#virastar-bulk-scan', function () {
			if (!window.confirm('اسکن انبوه شروع شود؟ محتوای مطالب تغییر نمی‌کند و فقط گزارش ثبت می‌شود.')) { return; }
			runBatches(allPublishedIds(), 'virastar_bulk_scan', 20, 'اسکن', function () {
				window.location.reload();
			});
		});

		$(document).on('click', '#virastar-bulk-fix', function () {
			if (!window.confirm('اصلاح انبوه اجرا شود؟ متن مطالب دارای مشکل به‌صورت خودکار اصلاح خواهد شد (برگشت‌پذیر نیست). توصیه: قبل از اجرا از سایت بکاپ بگیرید.')) { return; }
			var ids = allPublishedIds().filter(function (id) {
				var pill = $('#virastar-table tr[data-id="' + id + '"] .virastar-pill');
				return pill.length && !pill.hasClass('ok');
			});
			if (!ids.length) { ids = allPublishedIds(); }
			runBatches(ids, 'virastar_bulk_fix', 10, 'اصلاح', function () {
				window.location.reload();
			});
		});

		$(document).on('click', '.virastar-fix-one', function () {
			var id = parseInt($(this).closest('tr').data('id'), 10);
			var btn = $(this);
			btn.prop('disabled', true).text('در حال اصلاح…');
			$.post(D.ajax, {
				action: 'virastar_bulk_fix',
				nonce: D.nonce,
				ids: String(id)
			}).done(function (res) {
				if (res && res.success) {
					toast('مطلب اصلاح شد ✔', 'ok');
					window.location.reload();
				} else {
					btn.prop('disabled', false).text('خطا');
					toast('اصلاح ناموفق بود.', 'err');
				}
			}).fail(function () {
				btn.prop('disabled', false).text('خطا');
				toast('ارتباط با سرور برقرار نشد.', 'err');
			});
		});
	});
})();
