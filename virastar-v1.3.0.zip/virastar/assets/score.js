/**
 * Virastar Score — متاباکس «کیفیت محتوا و سئو» در ویرایشگر.
 *
 * هم با ویرایشگر کلاسیک و هم با گوتنبرگ کار می‌کند (بدون بیلد): محتوای
 * فعلی ویرایشگر را می‌خواند، به AJAX می‌فرستد و HTML رندرشدهٔ سمت سرور را
 * در متاباکس تزریق می‌کند. کلمه کلیدی سئو هم با همان درخواست ذخیره می‌شود.
 */
(function () {
        'use strict';

        var D = window.VirastarData || {};
        var $ = window.jQuery;

        function isGutenberg() {
                return !!(window.wp && window.wp.data && window.wp.data.select && window.wp.data.select('core/editor'));
        }

        function getContent() {
                if (isGutenberg()) {
                        return window.wp.data.select('core/editor').getEditedPostContent() || '';
                }
                if (window.tinyMCE && window.tinyMCE.activeEditor && !window.tinyMCE.activeEditor.isHidden()) {
                        return window.tinyMCE.activeEditor.getContent() || '';
                }
                var ta = document.getElementById('content');
                return ta ? ta.value : '';
        }

        function getTitle() {
                if (isGutenberg()) {
                        try { return window.wp.data.select('core/editor').getEditedPostAttribute('title') || ''; } catch (e) { /* noop */ }
                        return '';
                }
                var t = document.getElementById('title');
                return t ? t.value : '';
        }

        function esc(s) {
                return String(s == null ? '' : s)
                        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        }

        function run() {
                var box = document.getElementById('virastar-scorebox');
                if (!box) { return; }
                var out = document.getElementById('vx-score-result');
                if (!out) { return; }

                var kwEl = document.getElementById('vx-kw');
                var data = {
                        action: 'virastar_score',
                        nonce: D.nonce,
                        post_id: box.getAttribute('data-post') || 0,
                        content: getContent(),
                        title: getTitle()
                };
                if (kwEl) { data.focus_kw = kwEl.value; }

                out.html('<span class="vxs-loading">در حال محاسبهٔ امتیاز…</span>');

                $.post(D.ajax, data)
                        .done(function (res) {
                                if (res && res.success) {
                                        out.html(res.data.html);
                                } else {
                                        out.html('<p class="vxs-err">' + esc((res && res.data && res.data.message) || 'خطا در محاسبهٔ امتیاز.') + '</p>');
                                }
                        })
                        .fail(function () {
                                out.html('<p class="vxs-err">ارتباط با سرور برقرار نشد.</p>');
                        });
        }

        $(function () {
                $(document).on('click', '#vx-score-run', function (e) {
                        e.preventDefault();
                        run();
                });

                var box = document.getElementById('virastar-scorebox');
                if (box && box.getAttribute('data-auto') === '1') {
                        run();
                }
        });
})();
