<?php
/**
 * Virastar Pro — امکانات لایسنس‌دار افزونه «ویراستار».
 *
 * این فایل «فایل امکانات لایسنس‌دار» است و در بسته‌های محافظت‌شده (ionCube)
 * به‌صورت کدگذاری‌شده توزیع می‌شود. فایل اصلی افزونه (virastar.php) نقش
 * لودر را دارد و خودش هرگز کدگذاری نمی‌شود.
 *
 * راهنمای به‌روزرسانی: برای تغییر امکانات حرفه‌ای، همین فایل اصلی را ویرایش
 * کنید و سپس نسخه جدید آن را برای محافظت ارسال کنید. فایل محافظت‌شده را
 * باز، ویرایش یا دوباره ذخیره نکنید.
 *
 * امکانات حرفه‌ای: اسکن انبوه، اصلاح انبوه، خروجی CSV و اصلاح خودکار
 * هنگام ذخیره نوشته. بدون فایل لایسنس معتبر، هیچ‌کدام اجرا نمی‌شوند و
 * افزونه در حالت رایگان (موتور قواعد + اسکن تکی در ادیتور + گزارش هنگام
 * ذخیره) کار می‌کند.
 *
 * @package virastar
 */

if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

/**
 * امکانات حرفه‌ای ویراستار (لایسنس‌دار).
 *
 * متد activate() تنها از داخل بلوک لایسنس RTL در انتهای همین فایل و فقط
 * پس از تأیید صحت فایل لایسنس فراخوانی می‌شود.
 */
final class Virastar_Pro {

        const VERSION = '1.3.0';

        /** @var bool وضعیت لایسنس در این درخواست. */
        private static $active = false;

        /** آیا لایسنس (نسخه حرفه‌ای) در این درخواست فعال است؟ */
        public static function is_active() {
                return self::$active;
        }

        /**
         * فعال‌سازی هوک‌های امکانات حرفه‌ای.
         *
         * فقط از داخل بلوک لایسنس RTL فراخوانی می‌شود؛ در محیط تست نیز برای
         * شبیه‌سازی «لایسنس فعال» می‌توان آن را مستقیم صدا زد.
         */
        public static function activate() {
                if ( self::$active ) {
                        return;
                }
                self::$active = true;

                add_action( 'admin_post_virastar_export_csv', array( __CLASS__, 'export_csv' ) );
                add_action( 'wp_ajax_virastar_bulk_scan', array( __CLASS__, 'ajax_bulk_scan' ) );
                add_action( 'wp_ajax_virastar_bulk_fix', array( __CLASS__, 'ajax_bulk_fix' ) );
                add_action( 'save_post', array( __CLASS__, 'on_save_post_autofix' ), 20, 2 );
        }

        /* ------------------------------------------------------------------ *
         * محافظت AJAX
         * ------------------------------------------------------------------ */
        private static function ajax_guard( $capability = 'edit_posts' ) {
                if ( ! check_ajax_referer( 'virastar_ajax', 'nonce', false ) ) {
                        wp_send_json_error( array( 'message' => 'نشست منقضی شده؛ صفحه را تازه‌سازی کنید.' ), 403 );
                }
                if ( ! current_user_can( $capability ) ) {
                        wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز است.' ), 403 );
                }
        }

        /* ------------------------------------------------------------------ *
         * خروجی CSV از گزارش‌ها (حرفه‌ای)
         * ------------------------------------------------------------------ */
        public static function export_csv() {
                if ( ! current_user_can( Virastar_Admin::CAP ) ) { wp_die( 'دسترسی غیرمجاز است.', 403 ); }
                check_admin_referer( 'virastar_export_csv' );

                nocache_headers();
                header( 'Content-Type: text/csv; charset=UTF-8' );
                header( 'Content-Disposition: attachment; filename=virastar-report-' . gmdate( 'Y-m-d' ) . '.csv' );

                $out = fopen( 'php://output', 'w' );
                fwrite( $out, "\xEF\xBB\xBF" ); // Excel-friendly UTF-8 BOM.
                fputcsv( $out, array( 'Post ID', 'Title', 'Type', 'Issues', 'Details', 'Status', 'Checked at' ) );

                foreach ( Virastar_Admin::get_log() as $row ) {
                        $total  = Virastar_Admin::total_issues( $row['counts'] ?? array() );
                        $detail = array();
                        foreach ( ( $row['counts'] ?? array() ) as $k => $v ) {
                                $detail[] = ( Virastar_Engine::rule_labels()[ $k ] ?? $k ) . ': ' . $v;
                        }
                        fputcsv( $out, array(
                                $row['id'] ?? 0,
                                get_the_title( $row['id'] ?? 0 ),
                                $row['type'] ?? 'post',
                                $total,
                                implode( ' | ', $detail ),
                                ! empty( $row['fixed'] ) ? 'fixed' : ( 0 === $total ? 'clean' : 'pending' ),
                                $row['checked_at'] ?? '',
                        ) );
                }
                fclose( $out );
                exit;
        }

        /* ------------------------------------------------------------------ *
         * اسکن انبوه (حرفه‌ای): فقط گزارش، بدون تغییر محتوا
         * ------------------------------------------------------------------ */
        public static function ajax_bulk_scan() {
                self::ajax_guard( Virastar_Admin::CAP );

                $ids = isset( $_POST['ids'] ) ? array_filter( array_map( 'absint', explode( ',', (string) $_POST['ids'] ) ) ) : array();
                $done = array();

                foreach ( array_slice( $ids, 0, Virastar_Admin::BULK_BATCH ) as $pid ) {
                        $post = get_post( $pid );
                        if ( ! $post ) { continue; }
                        $res    = Virastar_Admin::analyze( $post->post_content );
                        $total  = Virastar_Admin::total_issues( $res['counts'] );

                        update_post_meta( $pid, Virastar_Admin::META_REPORT, array(
                                'counts'     => $res['counts'],
                                'suggestions'=> $res['suggestions'],
                                'total'      => $total,
                                'checked_at' => current_time( 'mysql' ),
                        ) );

                        $entry = array(
                                'id' => $pid, 'type' => $post->post_type, 'counts' => $res['counts'],
                                'fixed' => 0, 'checked_at' => current_time( 'mysql' ),
                        );
                        Virastar_Admin::log_update( $pid, $entry );
                        if ( class_exists( 'Virastar_Score' ) ) { Virastar_Score::store( $pid ); }
                        $done[] = $pid;
                }

                wp_send_json_success( array( 'done' => $done ) );
        }

        /* ------------------------------------------------------------------ *
         * اصلاح انبوه (حرفه‌ای): اعمال موتور قواعد روی محتوای مطالب
         * ------------------------------------------------------------------ */
        public static function ajax_bulk_fix() {
                self::ajax_guard( Virastar_Admin::CAP );

                $ids  = isset( $_POST['ids'] ) ? array_filter( array_map( 'absint', explode( ',', (string) $_POST['ids'] ) ) ) : array();
                $opts = Virastar_Admin::get_options();
                $done = array();
                $report = array();

                foreach ( array_slice( $ids, 0, Virastar_Admin::BULK_BATCH ) as $pid ) {
                        $post = get_post( $pid );
                        if ( ! $post ) { continue; }

                        $res   = Virastar_Admin::analyze( $post->post_content, $opts );
                        $total = Virastar_Admin::total_issues( $res['counts'] );

                        if ( $res['changed'] ) {
                                wp_update_post( array(
                                        'ID'           => $pid,
                                        'post_content' => $res['text'],
                                ) );
                        }

                        update_post_meta( $pid, Virastar_Admin::META_REPORT, array(
                                'counts'     => $res['counts'],
                                'suggestions'=> $res['suggestions'],
                                'total'      => $total,
                                'checked_at' => current_time( 'mysql' ),
                        ) );

                        $entry = array(
                                'id' => $pid, 'type' => $post->post_type, 'counts' => $res['counts'],
                                'fixed' => $res['changed'] ? 1 : 0, 'checked_at' => current_time( 'mysql' ),
                        );
                        Virastar_Admin::log_update( $pid, $entry );
                        if ( class_exists( 'Virastar_Score' ) ) { Virastar_Score::store( $pid ); }
                        $done[] = $pid;
                        $report[ $pid ] = $total;
                }

                wp_send_json_success( array( 'done' => $done, 'report' => $report ) );
        }

        /* ------------------------------------------------------------------ *
         * اصلاح خودکار هنگام ذخیره (حرفه‌ای) — اولویت ۲۰ (بعد از گزارش رایگان)
         * ------------------------------------------------------------------ */
        public static function on_save_post_autofix( $post_id, $post ) {
                if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) { return; }
                if ( ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) { return; }
                if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }

                $opts = Virastar_Admin::get_options();
                if ( empty( $opts['autofix_on_save'] ) ) { return; }

                $res = Virastar_Admin::analyze( $post->post_content, $opts );
                $changed = ! empty( $res['changed'] );

                if ( $changed ) {
                        // حذف موقت هوک برای جلوگیری از حلقه بازگشتی.
                        remove_action( 'save_post', array( __CLASS__, 'on_save_post_autofix' ), 20 );
                        wp_update_post( array( 'ID' => $post_id, 'post_content' => $res['text'] ) );
                        add_action( 'save_post', array( __CLASS__, 'on_save_post_autofix' ), 20, 2 );
                }

                $total = Virastar_Admin::total_issues( $res['counts'] );
                update_post_meta( $post_id, Virastar_Admin::META_REPORT, array(
                        'counts'     => $res['counts'],
                        'suggestions'=> $res['suggestions'],
                        'total'      => $total,
                        'checked_at' => current_time( 'mysql' ),
                ) );
                Virastar_Admin::log_update( $post_id, array(
                        'id' => $post_id, 'type' => $post->post_type, 'counts' => $res['counts'],
                        'fixed' => $changed ? 1 : 0, 'checked_at' => current_time( 'mysql' ),
                ) );
                if ( class_exists( 'Virastar_Score' ) ) { Virastar_Score::store( $post_id ); }
        }
}

// --------------------------------------------------------------------------------------------------- Start License Check

/**
 * بررسی لایسنس.
 *
 * ⚠️ نکته سازگاری: از وردپرس ۶.۸ فایل pluggable.php بعد از فایل افزونه‌ها
 * بارگذاری می‌شود؛ سازندهٔ کلاس لایسنس هنگام اجرا (bootstrap افزونهٔ همراه)
 * به توابع هسته مانند wp_generate_password نیاز دارد. برای همین بررسی لایسنس
 * در هوک plugins_loaded اجرا می‌شود که پس از بارگذاری کامل هسته است.
 */
if ( ! function_exists( 'virastar_license_check' ) ) {

    function virastar_license_check() {

        $licenseClassName = 'Virastar_License';

        if (
            class_exists($licenseClassName, false)
            && method_exists($licenseClassName, 'isActive')
        ) {
            try {
                $licenseReflection = new \ReflectionClass($licenseClassName);
                $licenseFilePath   = $licenseReflection->getFileName();

                if (is_string($licenseFilePath) && is_file($licenseFilePath)) {
                    $licenseFileHash = @sha1_file($licenseFilePath);

                    /* هش رسمی فایل لایسنس عیناً و به‌صورت literal داخل
                     * همین فایل قفل شده است. */
                    if (
                        is_string($licenseFileHash)
                        && hash_equals('5e315f6cab620892d7d24c71e0d3853010538ab8', $licenseFileHash)
                    ) {
                        $licenseClass = new $licenseClassName();

                        if ($licenseClass->{'isActive'}() === true) {
                            // لایسنس فعال است؛ کد امکانات لایسنس‌دار را اینجا قرار دهید.
                            /* بخش محصول: فعال‌سازی امکانات حرفه‌ای ویراستار.
                             * جدا از بلوک رسمی بالا، هر خطای احتمالی این بخش فقط
                             * به حالت رایگان منجر می‌شود و سایت از کار نمی‌افتد. */
                            try {
                                Virastar_Pro::activate();
                            } catch (\Throwable $e) {
                                // امکانات حرفه‌ای فعال نشد؛ حالت رایگان.
                            }
                        }
                    }
                }
            } catch (\ReflectionException $e) {
                // بررسی لایسنس ناموفق بود.
            }
        }
    }
}

add_action('plugins_loaded', 'virastar_license_check', 5);

// ----------------------------------------------------------------------------------------------------- End License Check
